import test from "node:test";
import assert from "node:assert/strict";
import { createDemoState } from "../src/demo-state.js";
import { createPlanningEngine } from "../src/planning/planning-engine.js";
import { createMemoryRepository } from "../src/repositories/state-repository.js";
import { createPlanService } from "../src/workflows/plan-service.js";
import { createSimulatedExecutionAdapter } from "../src/workflows/simulated-execution-adapter.js";

function sampleDevice(overrides = {}) {
  return {
    id: "SRV-PLAN-SERVICE",
    u_size: 4,
    rated_power_w: 1_200,
    real_power_w: null,
    weight_kg: 30,
    network_ports: 2,
    preferred_rack_ids: ["CAB-03"],
    ...overrides,
  };
}

function fixture() {
  const repository = createMemoryRepository(createDemoState());
  const service = createPlanService({
    repository,
    planner: createPlanningEngine(),
    executor: createSimulatedExecutionAdapter(),
  });
  return { repository, service };
}

test("placement with an existing device id returns a graceful blocker", async () => {
  const { service } = fixture();
  const first = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  assert.equal(first.validation.allowed, true);
  const executed = await service.confirm(first.id, "planner");
  assert.equal(executed.plan.status, "succeeded");
  const second = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  assert.equal(second.validation.allowed, false);
  assert.equal(second.validation.blockers[0].code, "DEVICE_ALREADY_EXISTS");
  assert.equal(second.original_candidates.length, 0);
});

test("a valid plan executes after one confirmation and writes linked audit", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");

  assert.equal(plan.status, "awaiting_confirmation");
  assert.equal(repository.read().devices.some((device) => device.id === sampleDevice().id), false);

  const result = await service.confirm(plan.id, "admin");
  const state = repository.read();
  assert.equal(result.plan.status, "succeeded");
  assert.equal(state.devices.some((device) => device.id === sampleDevice().id && device.status === "running"), true);
  assert.ok(state.audit.some((entry) => entry.entity_id === plan.id && entry.action === "plan_succeeded"));
  assert.ok(state.changes.some((change) => change.plan_id === plan.id && change.status === "succeeded"));
  await assert.rejects(() => service.confirm(plan.id, "admin"), (error) => error.code === "PLAN_ALREADY_CONFIRMED");
});

test("confirmation rejects a stale state version", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  repository.mutate(repository.read().version, (draft) => {
    draft.audit.push({ id: "EXTERNAL", action: "external_change" });
  });

  await assert.rejects(
    () => service.confirm(plan.id, "admin"),
    (error) => error.code === "PLAN_STALE" && error.plan_version < error.state_version,
  );
});

test("a request with no valid candidate never becomes confirmable", async () => {
  const { service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice({ id: "TOO-LARGE", u_size: 20 }) }, "planner");

  assert.equal(plan.status, "validated");
  assert.ok(plan.validation.blockers.some((issue) => issue.code === "NO_VALID_PLAN"));
  await assert.rejects(() => service.confirm(plan.id, "admin"), (error) => error.code === "PLAN_NOT_CONFIRMABLE");
});

test("warning plans still use exactly one final confirmation", async () => {
  const { service } = fixture();
  const plan = await service.create({
    kind: "placement",
    device: sampleDevice({ id: "POWER-WARNING", u_size: 2, rated_power_w: 8_000, preferred_rack_ids: ["CAB-01"] }),
  }, "planner");

  assert.equal(plan.status, "awaiting_confirmation");
  assert.ok(plan.validation.warnings.some((issue) => issue.code === "RACK_POWER_HIGH"));
  const result = await service.confirm(plan.id, "admin");
  assert.equal(result.plan.status, "succeeded");
  assert.equal(result.plan.confirmation_count, 1);
});

test("simulated execution failure rolls back inventory and records failure", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({
    kind: "placement",
    fail_at: "written",
    device: sampleDevice({ id: "FAIL-ROLLBACK" }),
  }, "planner");
  const deviceCount = repository.read().devices.length;

  const result = await service.confirm(plan.id, "admin");
  const state = repository.read();
  assert.equal(result.plan.status, "failed");
  assert.equal(result.execution.rolled_back, true);
  assert.equal(state.devices.length, deviceCount);
  assert.ok(state.audit.some((entry) => entry.entity_id === plan.id && entry.action === "plan_failed"));
});

test("request strategy overrides the stored default without mutating settings", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({ kind: "placement", strategy_id: "load_balanced", device: sampleDevice() }, "planner");
  assert.equal(plan.strategy_id, "load_balanced");
  assert.equal(repository.read().settings.placement.default_strategy_id, "balanced_optimal");
  assert.equal(plan.snapshot_version, plan.base_version);
});

test("invalid Agent alternative is audited and baseline remains confirmable", async () => {
  const repository = createMemoryRepository(createDemoState());
  const service = createPlanService({
    repository,
    planner: createPlanningEngine(),
    executor: createSimulatedExecutionAdapter(),
    agentGateway: { async adjustPlan() { return {
      candidate_id: null,
      reason: "Try an impossible position",
      weight_multipliers: { business: 1.5 },
      alternatives: [{ id: "BAD", reason: "overlap", actions: [{
        type: "place_device", rack_id: "CAB-02", layer_id: "L01", start_u: 1,
        device: { ...sampleDevice(), preferred_rack_ids: undefined, start_u: 1 },
      }] }],
    }; } },
  });
  const plan = await service.create({ kind: "placement", device: sampleDevice(), natural_language: "请部署一台测试服务器" }, "planner");
  assert.equal(plan.status, "awaiting_confirmation");
  assert.ok(plan.agent_intervention.rejected_alternatives.some((item) => item.id === "BAD"));
  assert.ok(repository.read().audit.some((entry) => entry.entity_id === plan.id && entry.details.rejected_alternative_ids.includes("BAD")));
});

test("server removal uses one final confirmation and leaves an audit trail", async () => {
  const { repository, service } = fixture();
  const removable = repository.read().devices.find((item) => item.movable && item.criticality === "normal" && item.maintenance_window);
  const plan = await service.create({
    kind: "removal",
    device_id: removable.id,
    actions: [{ type: "remove_device", device_id: removable.id, rack_id: removable.rack_id }],
    reasons: ["设备符合取出维护约束"],
  }, "planner");

  assert.equal(plan.status, "awaiting_confirmation");
  assert.equal(plan.kind, "removal");
  assert.equal(plan.confirmation_count, 0);

  const result = await service.confirm(plan.id, "admin");
  const state = repository.read();
  assert.equal(result.plan.status, "succeeded");
  assert.equal(result.plan.confirmation_count, 1);
  assert.equal(state.devices.some((item) => item.id === removable.id), false);
  assert.equal(state.audit.some((entry) => entry.entity_id === plan.id && entry.action === "plan_succeeded" && entry.details.kind === "removal"), true);
  await assert.rejects(() => service.confirm(plan.id, "admin"), (error) => error.code === "PLAN_ALREADY_CONFIRMED");
});

test("server removal plan replaces client display facts with canonical inventory", async () => {
  const { repository, service } = fixture();
  const removable = repository.read().devices.find((item) => item.movable && item.criticality === "normal" && item.maintenance_window);
  const plan = await service.create({
    kind: "removal",
    device_id: removable.id,
    actions: [{
      type: "remove_device",
      device_id: removable.id,
      rack_id: removable.rack_id,
      device: { id: removable.id, hostname: "tampered", business_id: "tampered" },
    }],
  }, "planner");

  assert.equal(plan.actions[0].device.hostname, removable.hostname);
  assert.equal(plan.actions[0].device.business_id, removable.business_id);
  assert.equal(plan.actions[0].device.maintenance_window, removable.maintenance_window);
});

test("server removal with upper devices generates moves to avoid suspended placements", async () => {
  const { repository, service } = fixture();
  const lower = repository.read().devices.find((item) => item.rack_id === "CAB-03" && item.layer_id === "L01" && item.start_u === 1);
  const upper = repository.read().devices.find((item) => item.rack_id === "CAB-03" && item.layer_id === "L01" && item.start_u === 7);
  assert.ok(lower);
  assert.ok(upper);

  const plan = await service.create({
    kind: "removal",
    device_id: lower.id,
    actions: [{ type: "remove_device", device_id: lower.id, rack_id: "CAB-03" }],
  }, "planner");

  assert.equal(plan.status, "awaiting_confirmation");
  assert.equal(plan.actions[0].type, "remove_device");
  const moves = plan.actions.filter((action) => action.type === "move_device");
  assert.equal(moves.length, 1);
  assert.equal(moves[0].device_id, upper.id);
  assert.equal(moves[0].start_u, 1);
  assert.equal(moves[0].source_start_u, 7);
  assert.equal(plan.migration_impact?.devices[0], upper.id);

  const result = await service.confirm(plan.id, "admin");
  assert.equal(result.plan.status, "succeeded");
  const state = repository.read();
  assert.equal(state.devices.some((item) => item.id === lower.id), false);
  const moved = state.devices.find((item) => item.id === upper.id);
  assert.equal(moved.start_u, 1);
});

test("server removal is blocked when an upper device cannot be migrated", async () => {
  const { repository, service } = fixture();
  const before = repository.read();
  const lower = before.devices.find((item) => item.rack_id === "CAB-03" && item.layer_id === "L01" && item.start_u === 1);
  const upper = before.devices.find((item) => item.rack_id === "CAB-03" && item.layer_id === "L01" && item.start_u === 7);
  assert.ok(lower);
  assert.ok(upper);

  repository.mutate(before.version, (draft) => {
    const target = draft.devices.find((item) => item.id === upper.id);
    if (target) target.movable = false;
  });

  const plan = await service.create({
    kind: "removal",
    device_id: lower.id,
    actions: [{ type: "remove_device", device_id: lower.id, rack_id: "CAB-03" }],
  }, "planner");

  assert.equal(plan.validation.allowed, false);
  assert.ok(plan.validation.blockers.some((item) => item.code === "DEVICE_UPPER_MOVE_NOT_ALLOWED"));
});

test("placement plan persists planner-owned solver provenance in plan and audit", async () => {
  const repository = createMemoryRepository(createDemoState());
  const baselinePlanner = createPlanningEngine({
    cpSatAdapter: {
      solve: () => ({
        outcome: "unavailable",
        candidates: [],
        solver: {
          engine: "beam_search",
          status: "disabled",
          duration_ms: 0,
          candidate_count: 0,
          fallback_reason: null,
        },
      }),
    },
  });
  const planner = {
    recommend(...args) {
      return {
        ...baselinePlanner.recommend(...args),
        solver: {
          engine: "cp_sat",
          status: "optimal",
          duration_ms: 17,
          candidate_count: 2,
          fallback_reason: null,
          validation_rejected_count: 1,
          validation_rejection_summary: [{ code: "DEVICE_U_OVERLAP", count: 1 }],
          payload: { unsafe: "must not persist" },
          stack: "must not persist",
        },
      };
    },
  };
  const service = createPlanService({
    repository,
    planner,
    executor: createSimulatedExecutionAdapter(),
  });

  const plan = await service.create({
    kind: "placement",
    device: sampleDevice({ id: "SOLVER-PROVENANCE" }),
    solver: { engine: "client-forged", status: "forged", candidate_count: 999 },
  }, "planner");

  assert.equal(plan.solver.engine, "cp_sat");
  assert.equal(plan.solver.candidate_count, 2);
  assert.equal(plan.solver.validation_rejected_count, 1);
  assert.deepEqual(plan.solver.validation_rejection_summary, [
    { code: "DEVICE_U_OVERLAP", count: 1 },
  ]);
  assert.equal(Object.hasOwn(plan.solver, "payload"), false);
  assert.equal(Object.hasOwn(plan.solver, "stack"), false);
  const audit = repository.read().audit.find((entry) =>
    entry.entity_id === plan.id && entry.action === "plan_created");
  assert.equal(audit.details.solver_engine, "cp_sat");
  assert.equal(audit.details.solver_status, "optimal");
  assert.equal(audit.details.solver_duration_ms, 17);
  assert.equal(audit.details.solver_candidate_count, 2);
  assert.equal(audit.details.solver_fallback_reason, null);
  assert.equal(audit.details.solver_validation_rejected_count, 1);
  assert.deepEqual(audit.details.solver_validation_rejection_summary, [
    { code: "DEVICE_U_OVERLAP", count: 1 },
  ]);
});

test("selecting a different candidate updates plan actions and validation", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  assert.equal(plan.original_candidates.length >= 2, true);

  const second = plan.original_candidates[1];
  const updated = service.selectCandidate(plan.id, second.id, "admin");

  assert.equal(updated.selected_candidate_id, second.id);
  assert.deepEqual(updated.actions, second.actions);
  assert.equal(updated.validation.allowed, true);
  assert.equal(updated.agent_score, second.score);
  assert.ok(updated.timeline.some((item) => item.status === "candidate_selected"));
  assert.ok(repository.read().audit.some((entry) =>
    entry.entity_id === plan.id && entry.action === "plan_candidate_selected" && entry.details.candidate_id === second.id));
});

test("selecting candidates multiple times keeps the plan selectable", async () => {
  const { service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  assert.equal(plan.original_candidates.length >= 3, true);

  const first = service.selectCandidate(plan.id, plan.original_candidates[1].id, "admin");
  assert.equal(first.selected_candidate_id, plan.original_candidates[1].id);

  const second = service.selectCandidate(first.id, plan.original_candidates[2].id, "admin");
  assert.equal(second.selected_candidate_id, plan.original_candidates[2].id);
  assert.equal(second.validation.allowed, true);
  assert.equal(second.snapshot_version, first.snapshot_version + 1);
});

test("selecting an unknown candidate or after confirmation is rejected", async () => {
  const { service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  assert.throws(
    () => service.selectCandidate(plan.id, "UNKNOWN", "admin"),
    (error) => error.code === "PLAN_CANDIDATE_NOT_FOUND",
  );

  await service.confirm(plan.id, "admin");
  assert.throws(
    () => service.selectCandidate(plan.id, plan.original_candidates[0].id, "admin"),
    (error) => error.code === "PLAN_ALREADY_CONFIRMED",
  );
});

test("selecting a candidate rejects stale state", async () => {
  const { repository, service } = fixture();
  const plan = await service.create({ kind: "placement", device: sampleDevice() }, "planner");
  repository.mutate(repository.read().version, (draft) => {
    draft.audit.push({ id: "EXTERNAL-1", action: "external_change" });
  });
  repository.mutate(repository.read().version, (draft) => {
    draft.audit.push({ id: "EXTERNAL-2", action: "external_change" });
  });

  assert.throws(
    () => service.selectCandidate(plan.id, plan.original_candidates[1].id, "admin"),
    (error) => error.code === "PLAN_STALE",
  );
});
