import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const launcherUrl = pathToFileURL(resolve("scripts/run-solver-tests.js")).href;

function invokeHandler(result, label = "CP-SAT Python tests") {
  const program = `
    import { handleChildResult } from ${JSON.stringify(launcherUrl)};
    const calls = [];
    const decision = handleChildResult(${JSON.stringify(result)}, ${JSON.stringify(label)}, {
      pid: 321,
      writeError: (message) => calls.push(["write", message]),
      kill: (pid, signal) => calls.push(["kill", pid, signal]),
      exit: (code) => calls.push(["exit", code]),
    });
    console.log(JSON.stringify({ decision, calls }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", program], {
    cwd: process.cwd(),
    encoding: "utf8",
    windowsHide: true,
    shell: false,
  });

  assert.equal(child.status, 0, child.stderr);
  return JSON.parse(child.stdout);
}

test("solver launcher accepts a PATH-resolved explicit interpreter override", () => {
  const result = spawnSync(process.execPath, ["scripts/run-solver-tests.js"], {
    cwd: process.cwd(),
    env: { ...process.env, CP_SAT_PYTHON: "node" },
    encoding: "utf8",
    windowsHide: true,
    shell: false,
  });

  assert.notEqual(result.status, 0);
  assert.doesNotMatch(result.stderr, /CP-SAT Python interpreter not found/);
});

test("solver launcher preserves a child termination signal", () => {
  const outcome = invokeHandler({ status: null, signal: "SIGTERM", error: null });

  assert.deepEqual(outcome, {
    decision: { kind: "signal", signal: "SIGTERM" },
    calls: [
      ["write", "CP-SAT Python tests was terminated by SIGTERM\n"],
      ["kill", 321, "SIGTERM"],
    ],
  });
});

test("solver launcher preserves nonzero and startup-failure handling", () => {
  assert.deepEqual(invokeHandler({ status: 7, signal: null, error: null }), {
    decision: { kind: "status", status: 7 },
    calls: [["exit", 7]],
  });
  assert.deepEqual(invokeHandler({ status: null, signal: null, error: { message: "spawn python ENOENT" } }), {
    decision: { kind: "error", message: "spawn python ENOENT" },
    calls: [
      ["write", "CP-SAT Python tests could not start: spawn python ENOENT\n"],
      ["exit", 1],
    ],
  });
});
