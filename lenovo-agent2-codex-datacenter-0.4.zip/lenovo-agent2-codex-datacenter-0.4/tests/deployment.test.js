import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

test("solver dependency is pinned and container owns Python runtime", () => {
  const requirements = readFileSync("requirements-solver.txt", "utf8");
  const dockerfile = readFileSync("Dockerfile", "utf8");

  assert.match(requirements, /^ortools==9\.15\.6755\s*$/m);
  assert.match(dockerfile, /python3\s+-m\s+venv\s+\/opt\/venv/);
  assert.match(dockerfile, /\/opt\/venv\/bin\/pip\s+install/);
  assert.match(dockerfile, /CP_SAT_ENABLED=true/);
  assert.match(dockerfile, /CP_SAT_PYTHON=\/opt\/venv\/bin\/python/);
  assert.match(dockerfile, /NODE_ENV=production/);
  assert.match(dockerfile, /HOST=0\.0\.0\.0/);
  assert.match(dockerfile, /EXPOSE 3000/);
});

test("container allow-lists runtime files and excludes local secrets", () => {
  const dockerfile = readFileSync("Dockerfile", "utf8");
  const dockerignore = readFileSync(".dockerignore", "utf8");

  assert.doesNotMatch(dockerfile, /^COPY\s+\.\s+\.$/m);
  assert.match(dockerfile, /^COPY server\.js \.\/$/m);
  assert.match(dockerfile, /^COPY src \.\/src$/m);
  assert.match(dockerfile, /^COPY public \.\/public$/m);
  assert.match(dockerfile, /^COPY data\/seed \.\/data\/seed$/m);
  assert.match(dockerfile, /^COPY solver\/cp_sat_solver\.py \.\/solver\/cp_sat_solver\.py$/m);
  assert.doesNotMatch(dockerfile, /COPY --chown=node:node/);
  for (const ignoredPath of [".env", ".env.*", "deploy/certs", "*.pem", "*.key", ".superpowers", ".playwright-cli", ".worktrees"]) {
    assert.match(dockerignore, new RegExp(`^${ignoredPath.replace(/[.*]/g, "\\$&")}$`, "m"));
  }
});

test("container stays non-root and includes the compose healthcheck client", () => {
  const dockerfile = readFileSync("Dockerfile", "utf8");
  const compose = readFileSync("compose.yaml", "utf8");

  assert.match(dockerfile, /apt-get install[^\n]*\bwget\b/);
  assert.match(compose, /test: \["CMD", "wget", "-qO-", "http:\/\/127\.0\.0\.1:3000\/health\/ready"\]/);
  assert.match(dockerfile, /mkdir -p \/app\/data\/runtime && chown node:node \/app\/data\/runtime/);
  assert.match(dockerfile, /chmod -R a-w \/app/);
  assert.match(dockerfile, /chmod u\+w \/app\/data\/runtime/);
  assert.doesNotMatch(dockerfile, /chown -R node:node \/app/);
  assert.match(dockerfile, /^USER node$/m);
});

test("README keeps the CP-SAT interpreter inside the container", () => {
  const readme = readFileSync("README.md", "utf8");

  assert.match(readme, /docker run --rm -p 127\.0\.0\.1:3000:3000 --env-file \.env --env HOST=0\.0\.0\.0 --env CP_SAT_PYTHON=\/opt\/venv\/bin\/python datacenter-mgr:cp-sat/);
  assert.match(readme, /远程访问必须使用[\s\S]*docker compose --profile https up -d/);
  assert.doesNotMatch(readme, /局域网临时访问/);
});

test("Compose passes bounded CP-SAT settings but fixes the container interpreter", () => {
  const compose = readFileSync("compose.yaml", "utf8");

  assert.match(compose, /CP_SAT_ENABLED:\s*\$\{CP_SAT_ENABLED:-true\}/);
  assert.match(compose, /CP_SAT_TIMEOUT_MS:\s*\$\{CP_SAT_TIMEOUT_MS:-2500\}/);
  assert.match(compose, /CP_SAT_PYTHON:\s*\/opt\/venv\/bin\/python/);
  assert.doesNotMatch(compose, /CP_SAT_PYTHON:\s*\$\{/);
});
