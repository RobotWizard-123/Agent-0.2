import test from "node:test";
import assert from "node:assert/strict";
import { getCpSatConfig } from "../src/config.js";
import { createDemoState } from "../src/demo-state.js";
import { buildCpSatProblem } from "../src/planning/cp-sat-slots.js";

function request(overrides = {}) {
  return {
    id: "CP-SAT-REQUEST",
    count: 1,
    u_size: 4,
    rated_power_w: 1_200,
    weight_kg: 30,
    network_ports: 2,
    preferred_rack_ids: [],
    business_id: null,
    replica_group: null,
    ...overrides,
  };
}

test("CP-SAT configuration is disabled by default and clamps process timeout", () => {
  assert.deepEqual(getCpSatConfig({}), {
    enabled: false,
    pythonPath: "python",
    timeoutMs: 2_500,
  });
  assert.deepEqual(getCpSatConfig({
    CP_SAT_ENABLED: "true",
    CP_SAT_PYTHON: "C:\\solver\\.venv\\Scripts\\python.exe",
    CP_SAT_TIMEOUT_MS: "100",
  }), {
    enabled: true,
    pythonPath: "C:\\solver\\.venv\\Scripts\\python.exe",
    timeoutMs: 500,
  });
});

test("slot builder places devices at the bottom of each free interval (no floating placements)", () => {
  const state = createDemoState();
  state.racks = state.racks.filter((rack) => rack.id === "CAB-01");
  state.devices = [];

  const problem = buildCpSatProblem(state, request(), {
    strategyId: "balanced_optimal",
    maxCandidates: 4,
    timeLimitMs: 2_000,
  });
  const l01 = problem.slots.filter((slot) => slot.rack_id === "CAB-01" && slot.layer_id === "L01");

  // 从下往上堆叠规则：每个空闲区间只生成一个候选位置（区间最底部 start_u），
  // 不允许悬空放置（即设备下方不能有空 U 位）。
  assert.deepEqual(l01.map((slot) => slot.start_u), [1]);
  assert.ok(l01.every((slot) => slot.end_u === slot.start_u + 3));
  assert.equal(problem.max_candidates, 4);
  assert.equal(problem.time_limit_ms, 2_000);
});

test("slot builder restricts 10U devices to L01 and blocks existing replica domains", () => {
  const state = createDemoState();
  const peer = state.devices.find((device) => device.rack_id === "CAB-01");
  peer.replica_group = "RG-CP-SAT";
  state.devices = state.devices.filter((device) => device.rack_id !== "CAB-11" || device.layer_id !== "L01");

  const problem = buildCpSatProblem(state, request({
    id: "CP-SAT-10U",
    u_size: 10,
    replica_group: "RG-CP-SAT",
  }), {
    strategyId: "load_balanced",
    maxCandidates: 9,
    timeLimitMs: 9_999,
  });
  const blockedRack = state.racks.find((rack) => rack.id === "CAB-01");

  assert.ok(problem.slots.length > 0);
  assert.ok(problem.slots.every((slot) => slot.layer_id === "L01"));
  assert.ok(problem.slots.every((slot) => slot.source_id !== blockedRack.source_id));
  assert.ok(problem.slots.every((slot) => slot.network_switch_id !== blockedRack.network_switch_id));
  assert.equal(problem.max_candidates, 4);
  assert.equal(problem.time_limit_ms, 2_000);
});

test("slot builder carries every final consolidated capacity dimension into the model", () => {
  const state = createDemoState();
  const snapshotRack = state.racks.find((rack) => rack.id === "CAB-01");
  state.racks = [snapshotRack];
  state.devices = state.devices.filter((device) => device.rack_id === snapshotRack.id);

  const problem = buildCpSatProblem(state, request({ count: 2 }), {
    strategyId: "consolidated",
  });
  const rack = problem.racks[0];

  assert.equal(rack.current_power_w, 2_400);
  assert.equal(rack.design_power_w, 10_000);
  assert.equal(rack.current_weight_kg, 16);
  assert.equal(rack.max_weight_kg, 420);
  assert.equal(rack.current_ports, 2);
  assert.equal(rack.port_limit, 24);
  assert.equal(rack.current_u, 2);
  assert.equal(rack.usable_u, 34);
});
