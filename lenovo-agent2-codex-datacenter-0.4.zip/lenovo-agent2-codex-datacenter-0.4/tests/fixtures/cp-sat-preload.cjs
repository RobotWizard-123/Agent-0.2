const { readFileSync } = require("node:fs");

const problem = JSON.parse(readFileSync(0, "utf8"));
const slot = problem.slots[0];
process.stdout.write(JSON.stringify({
  schema_version: 1,
  engine: "cp_sat",
  status: "optimal",
  duration_ms: 1,
  candidates: [{
    objective_value: 1,
    placements: [{
      device_index: 0,
      rack_id: slot.rack_id,
      layer_id: slot.layer_id,
      start_u: slot.start_u,
    }],
  }],
}));
process.exit(0);
