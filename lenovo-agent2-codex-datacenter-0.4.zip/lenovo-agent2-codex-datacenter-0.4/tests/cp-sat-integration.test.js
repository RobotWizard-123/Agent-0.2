import test from "node:test";
import assert from "node:assert/strict";
import { createDemoState } from "../src/demo-state.js";
import { evaluateActions } from "../src/domain/constraint-engine.js";
import { createCpSatAdapter } from "../src/planning/cp-sat-adapter.js";

const enabled = process.env.CP_SAT_INTEGRATION === "1";

test("real Python OR-Tools process returns revalidated placement candidates", { skip: !enabled }, () => {
  const adapter = createCpSatAdapter({
    config: {
      enabled: true,
      pythonPath: process.env.CP_SAT_PYTHON || ".venv\\Scripts\\python.exe",
      timeoutMs: 2_500,
    },
    validator: evaluateActions,
  });
  const result = adapter.solve(createDemoState(), {
    id: "REAL-CP-SAT",
    count: 2,
    u_size: 2,
    rated_power_w: 800,
    weight_kg: 20,
    network_ports: 2,
    preferred_rack_ids: [],
    business_id: "compute-platform",
    replica_group: "RG-REAL-CP",
  }, { strategyId: "balanced_optimal" });

  assert.equal(result.outcome, "success");
  assert.ok(result.candidates.length >= 1 && result.candidates.length <= 4);
  assert.ok(result.candidates.every((candidate) => candidate.validation.allowed));
  assert.equal(result.solver.engine, "cp_sat");
});
