@echo off
title Datacenter Agent V0.2 Launcher

REM --- Switch to script directory ---
cd /d "%~dp0"

REM --- Check Node.js ---
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ============================================================
    echo   ERROR: Node.js not found!
    echo ============================================================
    echo.
    echo Please install Node.js v22 or higher:
    echo   Download: https://nodejs.org/
    echo.
    echo Then re-run this script.
    echo.
    pause
    exit /b 1
)

REM --- Run the Node.js launcher (all UI logic and Chinese text is here) ---
node scripts\launcher.js

REM --- Keep window if launcher failed ---
if %errorlevel% neq 0 (
    echo.
    echo Launch failed. Please check errors above.
    pause
)
