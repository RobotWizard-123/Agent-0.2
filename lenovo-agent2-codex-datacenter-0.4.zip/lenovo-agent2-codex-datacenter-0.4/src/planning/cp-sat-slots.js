import { capacitySnapshot } from "../domain/capacity.js";
import { freeIntervals } from "../domain/rack-layout.js";
import { strategyProfile } from "./strategy-profiles.js";

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, Number(value) || 0));
}

function activeDevices(state, rackId) {
  return state.devices.filter((device) => device.rack_id === rackId && device.status !== "cancelled");
}

function projectedCapacityMetric(snapshot, request) {
  return Math.round(100 * Math.max(
    (snapshot.rated_power_used_w + request.rated_power_w) / snapshot.design_power_w,
    (snapshot.used_weight_kg + request.weight_kg) / snapshot.max_weight_kg,
    (snapshot.used_ports + request.network_ports) / snapshot.port_limit,
    (snapshot.used_u + request.u_size) / snapshot.usable_u,
  ));
}

function sourceRatios(state) {
  const sources = new Map();
  for (const rack of state.racks.filter((item) => item.role === "server")) {
    const snapshot = capacitySnapshot(state, rack.id);
    const current = sources.get(rack.source_id) ?? { used: 0, capacity: 0 };
    current.used += snapshot.rated_power_used_w;
    current.capacity += snapshot.design_power_w;
    sources.set(rack.source_id, current);
  }
  return new Map([...sources].map(([id, source]) => [
    id,
    source.capacity > 0 ? source.used / source.capacity : 0,
  ]));
}

function slotMetrics({ state, request, rack, interval, snapshot, businessRacks, businessSwitches, ratios }) {
  const remaining = interval.size_u - request.u_size;
  const preferred = request.preferred_rack_ids.length > 0 && !request.preferred_rack_ids.includes(rack.id) ? 100 : 0;
  const business = request.business_id && businessRacks.size > 0 && !businessRacks.has(rack.id) ? 100 : 0;
  const link = request.business_id && businessSwitches.size > 0 && !businessSwitches.has(rack.network_switch_id) ? 100 : 0;
  const capacity = clamp(projectedCapacityMetric(snapshot, request), 0, 100);
  const sourceRatio = ratios.get(rack.source_id) ?? 0;
  const projectedSourceRatio = sourceRatio + request.rated_power_w
    / state.racks.filter((item) => item.source_id === rack.source_id)
      .reduce((sum, item) => sum + Number(item.design_power_w), 0);
  return {
    preferred,
    business,
    fragmentation: clamp(100 - remaining * 10, 0, 100),
    link,
    capacity,
    growth: clamp(100 - remaining * 10, 0, 100),
    activation: activeDevices(state, rack.id).length === 0 ? 100 : 0,
    source_imbalance: clamp(projectedSourceRatio * 100, 0, 100),
    migration: 0,
  };
}

function weightedCost(metrics, weights) {
  return Math.round(Object.entries(weights)
    .reduce((sum, [metric, weight]) => sum + Number(metrics[metric] ?? 0) * Number(weight), 0));
}

export function buildCpSatProblem(state, request, {
  strategyId = "balanced_optimal",
  maxCandidates = 4,
  timeLimitMs = 2_000,
} = {}) {
  const profile = strategyProfile(strategyId);
  const businessRacks = new Set(state.devices
    .filter((device) => request.business_id && device.business_id === request.business_id && device.status !== "cancelled")
    .map((device) => device.rack_id));
  const businessSwitches = new Set(state.racks
    .filter((rack) => businessRacks.has(rack.id))
    .map((rack) => rack.network_switch_id));
  const existingReplicaRacks = new Set(state.devices
    .filter((device) => request.replica_group && device.replica_group === request.replica_group && device.status !== "cancelled")
    .map((device) => device.rack_id));
  const blockedSources = new Set(state.racks.filter((rack) => existingReplicaRacks.has(rack.id)).map((rack) => rack.source_id));
  const blockedSwitches = new Set(state.racks.filter((rack) => existingReplicaRacks.has(rack.id)).map((rack) => rack.network_switch_id));
  const ratios = sourceRatios(state);
  const racks = [];
  const slots = [];

  for (const rack of state.racks.filter((item) => item.role === "server")) {
    const snapshot = capacitySnapshot(state, rack.id);
    racks.push({
      id: rack.id,
      source_id: rack.source_id,
      network_switch_id: rack.network_switch_id,
      design_power_w: Number(snapshot.design_power_w),
      current_power_w: Number(snapshot.rated_power_used_w),
      remaining_power_w: Number(snapshot.design_power_w) - Number(snapshot.rated_power_used_w),
      current_weight_kg: Number(snapshot.used_weight_kg),
      max_weight_kg: Number(snapshot.max_weight_kg),
      remaining_weight_kg: Number(snapshot.max_weight_kg) - Number(snapshot.used_weight_kg),
      current_ports: Number(snapshot.used_ports),
      port_limit: Number(snapshot.port_limit),
      remaining_ports: Number(snapshot.port_limit) - Number(snapshot.used_ports),
      current_u: Number(snapshot.used_u),
      usable_u: Number(snapshot.usable_u),
      activated: activeDevices(state, rack.id).length > 0,
    });
    if (request.replica_group && (blockedSources.has(rack.source_id) || blockedSwitches.has(rack.network_switch_id))) continue;

    const intervals = freeIntervals(rack, activeDevices(state, rack.id))
      .filter((interval) => interval.size_u >= request.u_size)
      .filter((interval) => request.u_size !== 10 || interval.layer_id === "L01");
    for (const interval of intervals) {
      const metrics = slotMetrics({
        state, request, rack, interval, snapshot, businessRacks, businessSwitches, ratios,
      });
      if (strategyId === "consolidated" && metrics.capacity >= 80) continue;
      // 从下往上堆叠：设备只能放在空闲区间的最底部（interval.start_u），
      // 不允许悬空放置（即设备下方不能有空 U 位）。
      const startU = interval.start_u;
      slots.push({
        id: `${rack.id}:${interval.layer_id}:${startU}`,
        rack_id: rack.id,
        layer_id: interval.layer_id,
        start_u: startU,
        end_u: startU + request.u_size - 1,
        source_id: rack.source_id,
        network_switch_id: rack.network_switch_id,
        soft_cost: weightedCost(metrics, profile.weights),
      });
    }
  }

  return {
    schema_version: 1,
    strategy_id: strategyId,
    max_candidates: Math.min(4, Math.max(1, Number(maxCandidates) || 4)),
    time_limit_ms: Math.min(2_000, Math.max(50, Number(timeLimitMs) || 2_000)),
    request: {
      id: request.id,
      count: Number(request.count),
      u_size: Number(request.u_size),
      rated_power_w: Number(request.rated_power_w),
      weight_kg: Number(request.weight_kg),
      network_ports: Number(request.network_ports),
      replica_group: request.replica_group ?? null,
    },
    racks: racks.sort((left, right) => left.id.localeCompare(right.id)),
    slots: slots.sort((left, right) => left.id.localeCompare(right.id)),
  };
}
