import { applyActions, evaluateActions } from "../domain/constraint-engine.js";
import { capacitySnapshot } from "../domain/capacity.js";
import { freeIntervals } from "../domain/rack-layout.js";

export function placementDevice(request, index, startU) {
  const suffix = request.count > 1 ? `-${index + 1}` : "";
  return {
    ...structuredClone(request),
    id: `${request.id}${suffix}`,
    it_code: request.it_code && request.count > 1 ? `${request.it_code}-${index + 1}` : request.it_code,
    count: undefined,
    preferred_rack_ids: undefined,
    start_u: startU,
    status: "pending",
    data_source: "demo",
    // 新部署设备默认满足取出条件
    movable: true,
    criticality: "normal",
    maintenance_window: "Saturday 02:00-04:00",
  };
}

function availableIntervals(state, request) {
  return state.racks
    .filter((rack) => rack.role === "server")
    .flatMap((rack) => {
      try {
        return freeIntervals(
          rack,
          state.devices.filter((device) => device.rack_id === rack.id && device.status !== "cancelled"),
        );
      } catch {
        return [];
      }
    })
    .filter((interval) => interval.size_u >= request.u_size)
    .filter((interval) => request.u_size !== 10 || interval.layer_id === "L01")
    .sort((left, right) => left.rack_id.localeCompare(right.rack_id)
      || left.layer_id.localeCompare(right.layer_id)
      || left.start_u - right.start_u);
}

function replicaDomainAvailable(state, request, actions, rackId) {
  if (!request.replica_group) return true;
  const rack = state.racks.find((item) => item.id === rackId);
  const priorRacks = actions
    .filter((action) => action.type === "place_device")
    .map((action) => state.racks.find((item) => item.id === action.rack_id))
    .filter(Boolean);
  return priorRacks.every((prior) => prior.source_id !== rack.source_id
    && prior.network_switch_id !== rack.network_switch_id);
}

function actionKey(actions) {
  return actions.map((action) => {
    if (action.type === "set_dividers") return `0-${action.rack_id}-${action.dividers_u.join("-")}`;
    return `1-${action.rack_id}-${action.layer_id}-${String(action.start_u).padStart(2, "0")}`;
  }).join("--");
}

const MAX_EXPANSIONS_PER_ITERATION = 2000;
// 超过该数量后，beam search 的指数展开会导致响应极慢甚至 OOM，
// 切换为单次投影的贪心直接放置。
const GREEDY_DIRECT_THRESHOLD = 8;

function applyPlaceInPlace(projected, action) {
  projected.devices.push({
    ...action.device,
    rack_id: action.rack_id,
    layer_id: action.layer_id,
    start_u: Number(action.start_u),
    status: action.device?.status ?? "pending",
    data_source: action.device?.data_source ?? "demo",
    movable: action.device?.movable ?? true,
    criticality: action.device?.criticality ?? "normal",
    maintenance_window: action.device?.maintenance_window ?? "Saturday 02:00-04:00",
  });
}

function boundedAllowedExpansions(baseState, expansions, maxBeams, validator) {
  const rackCount = Math.max(1, baseState.racks.filter((rack) => rack.role === "server").length);
  const perFirstRack = Math.max(1, Math.floor(maxBeams / rackCount));
  const counts = new Map();
  const accepted = [];

  for (const expansion of expansions.sort((left, right) => actionKey(left.actions).localeCompare(actionKey(right.actions)))) {
    const firstRack = expansion.actions.find((action) => action.type === "place_device")?.rack_id ?? "none";
    if ((counts.get(firstRack) ?? 0) >= perFirstRack) continue;
    const validation = validator(baseState, expansion.actions);
    if (!validation.allowed) continue;
    accepted.push({ ...expansion, validation });
    counts.set(firstRack, (counts.get(firstRack) ?? 0) + 1);
    if (accepted.length >= maxBeams) break;
  }
  return accepted;
}

function candidateSlotTuples(state, request) {
  const tuples = [];
  for (const interval of availableIntervals(state, request)) {
    // 从下往上堆叠：设备只能放在空闲区间的最底部（interval.start_u），
    // 不允许悬空放置（即设备下方不能有空 U 位）。
    tuples.push({ rack_id: interval.rack_id, layer_id: interval.layer_id, start_u: interval.start_u });
  }
  return tuples;
}

function expandPlacementBeams(baseState, request, { maxBeams, validator, initialBeam }) {
  let beams = [initialBeam ?? { actions: [], projected: structuredClone(baseState), validation: null }];

  for (let index = 0; index < request.count; index += 1) {
    const device = placementDevice(request, index, 0);
    const expansions = [];
    let attempts = 0;

    for (const beam of beams) {
      const slots = candidateSlotTuples(beam.projected, request);
      // 按确定性顺序排序，确保结果稳定
      slots.sort((left, right) =>
        left.rack_id.localeCompare(right.rack_id)
        || left.layer_id.localeCompare(right.layer_id)
        || left.start_u - right.start_u);

      for (const slot of slots) {
        attempts += 1;
        if (attempts > MAX_EXPANSIONS_PER_ITERATION) break;
        if (!replicaDomainAvailable(baseState, request, beam.actions, slot.rack_id)) continue;
        const action = {
          type: "place_device",
          rack_id: slot.rack_id,
          layer_id: slot.layer_id,
          start_u: slot.start_u,
          device: { ...device, start_u: slot.start_u },
        };
        try {
          expansions.push({
            actions: [...beam.actions, action],
            projected: applyActions(beam.projected, [action]),
          });
        } catch {
          // Skip expansions that violate hard constraints (e.g. duplicate device ID).
        }
      }
      if (attempts > MAX_EXPANSIONS_PER_ITERATION) break;
    }
    beams = boundedAllowedExpansions(baseState, expansions, maxBeams, validator);
    if (beams.length === 0) break;
  }
  return beams;
}

function rackUtilization(rack, used, request) {
  const powerRatio = (used.rated_power_w + Number(request.rated_power_w || 0)) / Math.max(1, Number(rack.design_power_w));
  const weightRatio = (used.weight_kg + Number(request.weight_kg || 0)) / Math.max(1, Number(rack.max_weight_kg));
  const portRatio = (used.network_ports + Number(request.network_ports || 0)) / Math.max(1, Number(rack.network_port_limit));
  const uRatio = (used.used_u + Number(request.u_size || 0)) / Math.max(1, Number(capacitySnapshot({ racks: [rack], devices: [] }, rack.id).usable_u));
  return Math.max(powerRatio, weightRatio, portRatio, uRatio);
}

function greedyDirectPlacement(baseState, request, { validator }) {
  const projected = structuredClone(baseState);
  const actions = [];
  const serverRacks = baseState.racks.filter((rack) => rack.role === "server");
  const rackUsage = new Map();

  function refreshRackUsage(rackId) {
    const devices = projected.devices.filter((device) => device.rack_id === rackId && device.status !== "cancelled");
    rackUsage.set(rackId, {
      rated_power_w: devices.reduce((sum, d) => sum + Number(d.rated_power_w || 0), 0),
      weight_kg: devices.reduce((sum, d) => sum + Number(d.weight_kg || 0), 0),
      network_ports: devices.reduce((sum, d) => sum + Number(d.network_ports || 0), 0),
      used_u: devices.reduce((sum, d) => sum + Number(d.u_size || 0), 0),
    });
  }

  for (const rack of serverRacks) refreshRackUsage(rack.id);

  for (let index = 0; index < request.count; index += 1) {
    const device = placementDevice(request, index, 0);
    const slots = candidateSlotTuples(projected, request);
    if (slots.length === 0) return null;

    // 按负载均衡排序：优先选择放置后利用率最低的机柜，
    // 同时保持确定性（rack_id / layer_id / start_u 作为 tie-breaker）
    const rackById = new Map(serverRacks.map((rack) => [rack.id, rack]));
    slots.sort((left, right) => {
      const leftRack = rackById.get(left.rack_id);
      const rightRack = rackById.get(right.rack_id);
      const leftUtil = leftRack ? rackUtilization(leftRack, rackUsage.get(left.rack_id) ?? { rated_power_w: 0, weight_kg: 0, network_ports: 0, used_u: 0 }, request) : Infinity;
      const rightUtil = rightRack ? rackUtilization(rightRack, rackUsage.get(right.rack_id) ?? { rated_power_w: 0, weight_kg: 0, network_ports: 0, used_u: 0 }, request) : Infinity;
      if (leftUtil !== rightUtil) return leftUtil - rightUtil;
      return left.rack_id.localeCompare(right.rack_id)
        || left.layer_id.localeCompare(right.layer_id)
        || left.start_u - right.start_u;
    });

    let placed = false;
    for (const slot of slots) {
      if (!replicaDomainAvailable(baseState, request, actions, slot.rack_id)) continue;
      const action = {
        type: "place_device",
        rack_id: slot.rack_id,
        layer_id: slot.layer_id,
        start_u: slot.start_u,
        device: { ...device, start_u: slot.start_u },
      };
      try {
        applyPlaceInPlace(projected, action);
        actions.push(action);
        refreshRackUsage(slot.rack_id);
        placed = true;
        break;
      } catch {
        // 当前槽位不可用（如 ID 冲突），尝试下一个槽位
      }
    }
    if (!placed) return null;
  }

  const validation = validator(baseState, actions);
  if (!validation.allowed) return null;

  return { actions, projected, validation };
}

function dividerLayoutFor(layerId, requiredCapacityU) {
  if (layerId === "L01" || requiredCapacityU <= 10 || requiredCapacityU > 26) return null;
  const targetIndex = Number(layerId.slice(-1)) - 2;
  const sizes = [0, 0, 0];
  sizes[targetIndex] = requiredCapacityU;
  const remaining = 30 - requiredCapacityU;
  const otherIndexes = [0, 1, 2].filter((index) => index !== targetIndex);
  sizes[otherIndexes[0]] = Math.floor(remaining / 2);
  sizes[otherIndexes[1]] = Math.ceil(remaining / 2);
  if (sizes.some((size) => size < 2)) return null;
  return [12, 12 + sizes[0], 12 + sizes[0] + sizes[1]];
}

function toCandidate(beam) {
  const placements = beam.actions.filter((action) => action.type === "place_device");
  const divider = beam.actions.find((action) => action.type === "set_dividers");
  const prefix = divider ? `DIVIDER-${divider.rack_id}-${divider.dividers_u.join("-")}` : "DIRECT";
  return {
    id: `${prefix}-${actionKey(placements)}`,
    rack_id: placements[0]?.rack_id ?? divider?.rack_id,
    layer_id: placements[0]?.layer_id ?? null,
    actions: beam.actions,
    validation: beam.validation,
  };
}

export function generateDirectPlacementCandidates(state, request, {
  maxBeams = 64,
  validator = evaluateActions,
} = {}) {
  const count = Number(request.count ?? 1);
  // 大批量直接使用贪心投影，避免 beam search 的状态爆炸
  if (count > GREEDY_DIRECT_THRESHOLD) {
    const greedy = greedyDirectPlacement(state, request, { validator });
    return greedy ? [toCandidate(greedy)] : [];
  }
  const beamLimit = Math.max(1, Math.min(256, Number(maxBeams) || 64));
  return expandPlacementBeams(state, request, { maxBeams: beamLimit, validator }).map(toCandidate);
}

export function generateDividerCandidates(state, request, {
  maxBeams = 64,
  validator = evaluateActions,
} = {}) {
  const count = Number(request.count ?? 1);
  // 挡板调整最多只能扩展单个机柜的某一层，无法容纳大批量设备，直接跳过
  if (count > GREEDY_DIRECT_THRESHOLD || request.u_size === 10) return [];
  const beamLimit = Math.max(1, Math.min(256, Number(maxBeams) || 64));

  const dividerBeams = [];
  for (const rack of state.racks.filter((item) => item.role === "server")) {
    for (const layerId of ["L02", "L03", "L04"]) {
      const dividersU = dividerLayoutFor(layerId, request.u_size + 2);
      if (!dividersU || dividersU.every((value, index) => value === rack.dividers_u[index])) continue;
      const dividerAction = { type: "set_dividers", rack_id: rack.id, dividers_u: dividersU };
      const dividerValidation = validator(state, [dividerAction]);
      if (!dividerValidation.allowed) continue;
      const projected = applyActions(state, [dividerAction]);
      const beams = expandPlacementBeams(state, request, {
        maxBeams: beamLimit,
        validator,
        initialBeam: { actions: [dividerAction], projected, validation: dividerValidation },
      }).filter((beam) => beam.actions.some((action) => action.type === "place_device"
        && action.rack_id === rack.id && action.layer_id === layerId));
      dividerBeams.push(...beams);
      if (dividerBeams.length >= beamLimit) break;
    }
    if (dividerBeams.length >= beamLimit) break;
  }

  return dividerBeams
    .sort((left, right) => actionKey(left.actions).localeCompare(actionKey(right.actions)))
    .slice(0, beamLimit)
    .map(toCandidate);
}

export function generatePlacementCandidates(state, request, options = {}) {
  const direct = generateDirectPlacementCandidates(state, request, options);
  if (direct.length > 0) return direct;
  return generateDividerCandidates(state, request, options);
}
