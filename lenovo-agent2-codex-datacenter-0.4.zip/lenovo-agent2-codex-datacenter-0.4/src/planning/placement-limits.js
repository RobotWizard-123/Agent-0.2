export const MAX_PLACEMENT_DEVICE_COUNT = 100;
export const MAX_CP_SAT_ASSIGNMENT_VARIABLES = 20_000;

export function normalizePlacementCount(value) {
  const count = value === undefined ? 1 : value;
  if (!Number.isInteger(count) || count <= 0 || count > MAX_PLACEMENT_DEVICE_COUNT) {
    throw Object.assign(
      new Error(`Placement count must be an integer from 1 to ${MAX_PLACEMENT_DEVICE_COUNT}`),
      { code: "PLACEMENT_COUNT_INVALID" },
    );
  }
  return count;
}
