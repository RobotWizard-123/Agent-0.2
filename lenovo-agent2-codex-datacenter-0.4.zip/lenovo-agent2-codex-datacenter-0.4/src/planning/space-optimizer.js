import { applyActions, evaluateActions } from "../domain/constraint-engine.js";
import { deriveLayers, freeIntervals } from "../domain/rack-layout.js";

function uIntervalText(startU, sizeU) {
  const start = Number(startU);
  const size = Math.max(1, Number(sizeU) || 1);
  return Number.isFinite(start) ? `U${start}–U${start + size - 1}` : "U 位待定";
}

function makeDevice(request, index, startU) {
  const suffix = request.count > 1 ? `-${index + 1}` : "";
  return {
    ...structuredClone(request),
    id: `${request.id}${suffix}`,
    it_code: request.it_code && request.count > 1 ? `${request.it_code}-${index + 1}` : request.it_code,
    count: undefined,
    preferred_rack_ids: undefined,
    start_u: startU,
    status: "pending",
    data_source: "demo",
    movable: request.movable ?? true,
    criticality: request.criticality ?? "normal",
    maintenance_window: request.maintenance_window ?? "Saturday 02:00-04:00",
  };
}

function eligibilityReason(device) {
  if (!device.movable) return "DEVICE_MOVE_NOT_ALLOWED";
  if (device.criticality === "critical") return "DEVICE_CRITICAL";
  if (!device.maintenance_window) return "MAINTENANCE_WINDOW_REQUIRED";
  return null;
}

function movedImpactMeta(state, movedDeviceIds) {
  const originals = movedDeviceIds
    .map((id) => state.devices.find((d) => d.id === id))
    .filter(Boolean);
  const windows = [...new Set(originals.map((d) => d.maintenance_window).filter(Boolean))];
  return {
    devices: originals.map((d) => d.id),
    businesses: [...new Set(originals.map((d) => d.business_id).filter(Boolean))],
    maintenance_window: windows.length ? windows.join("; ") : null,
  };
}

function intervalsFor(state, rack, sizeU, options = {}) {
  try {
    return freeIntervals(
      rack,
      state.devices.filter((device) => device.rack_id === rack.id && device.status !== "cancelled"),
    )
      .filter((interval) => {
        if (interval.size_u < sizeU) return false;
        if (sizeU === 10 && !options.allowNonL01) return interval.layer_id === "L01";
        return true;
      })
      .sort((left, right) => {
        if (options.preferL01) {
          if (left.layer_id === "L01" && right.layer_id !== "L01") return -1;
          if (right.layer_id === "L01" && left.layer_id !== "L01") return 1;
        }
        return left.layer_id.localeCompare(right.layer_id) || left.start_u - right.start_u;
      });
  } catch {
    return [];
  }
}

function movableDevicesInLayer(state, rackId, layerId) {
  return state.devices
    .filter((d) => d.rack_id === rackId && d.layer_id === layerId && d.status !== "cancelled" && d.status === "running")
    .filter((d) => !eligibilityReason(d))
    .sort((a, b) => Number(a.start_u) - Number(b.start_u));
}

function movableDevicesInRack(state, rackId) {
  return state.devices
    .filter((d) => d.rack_id === rackId && d.status !== "cancelled" && d.status === "running")
    .filter((d) => !eligibilityReason(d))
    .sort((a, b) => Number(a.start_u) - Number(b.start_u));
}

function canMoveDeviceTo(state, device, destRack, options = {}) {
  const intervals = intervalsFor(state, destRack, Number(device.u_size), { allowNonL01: true });
  let filtered = intervals;
  if (options.preserveL01) {
    const nonL01 = intervals.filter((i) => i.layer_id !== "L01");
    if (nonL01.length > 0) filtered = nonL01;
  }
  return filtered.length > 0 ? filtered[0] : null;
}

function tryEvacuateLayer(state, rack, layerId, requiredU, serverRacks) {
  const layerDevices = state.devices
    .filter((d) => d.rack_id === rack.id && d.layer_id === layerId && d.status !== "cancelled" && d.status === "running")
    .sort((a, b) => Number(a.start_u) - Number(b.start_u));

  if (layerDevices.length === 0) return null;

  const movable = layerDevices.filter((d) => !eligibilityReason(d));
  if (movable.length !== layerDevices.length) return null;

  let projected = structuredClone(state);
  const moveActions = [];
  let allEvacuated = true;
  const movedOrigins = [];

  // 辅助函数：直接更新投影状态中的设备位置，避免每次迁移都结构化克隆整个状态
  function applyMoveInPlace(action) {
    const projDevice = projected.devices.find((d) => d.id === action.device_id);
    if (!projDevice) throw new Error(`Device not found in projection: ${action.device_id}`);
    projDevice.rack_id = action.rack_id;
    projDevice.layer_id = action.layer_id;
    projDevice.start_u = Number(action.start_u);
  }

  for (const device of layerDevices) {
    let placed = false;

    // 优先尝试同机柜内的层间迁移：风险最低、操作最简单
    const otherLayersInRack = deriveLayers(rack).filter((l) => l.id !== layerId);
    for (const layer of otherLayersInRack) {
      const layerIntervals = intervalsFor(projected, rack, Number(device.u_size), { allowNonL01: true })
        .filter((i) => i.layer_id === layer.id);
      if (layerIntervals.length > 0) {
        const dest = layerIntervals[0];
        const action = {
          type: "move_device",
          device_id: device.id,
          rack_id: rack.id,
          layer_id: dest.layer_id,
          start_u: dest.start_u,
          u_size: device.u_size,
          source_rack_id: device.rack_id,
          source_layer_id: device.layer_id,
          source_start_u: device.start_u,
          source_u_size: device.u_size,
        };
        moveActions.push(action);
        movedOrigins.push({ device_id: device.id, rack_id: device.rack_id, layer_id: device.layer_id, start_u: device.start_u });
        try {
          applyMoveInPlace(action);
        } catch {
          allEvacuated = false;
          break;
        }
        placed = true;
        break;
      }
    }
    if (placed) continue;

    const destRacks = serverRacks
      .filter((r) => r.id !== rack.id)
      .sort((a, b) => {
        const aHasFreeL01 = intervalsFor(projected, a, 10, {}).length > 0;
        const bHasFreeL01 = intervalsFor(projected, b, 10, {}).length > 0;
        if (aHasFreeL01 && !bHasFreeL01) return 1;
        if (bHasFreeL01 && !aHasFreeL01) return -1;
        const aFree = intervalsFor(projected, a, Number(device.u_size), { allowNonL01: true }).length;
        const bFree = intervalsFor(projected, b, Number(device.u_size), { allowNonL01: true }).length;
        return bFree - aFree;
      });

    for (const destRack of destRacks) {
      const dest = canMoveDeviceTo(projected, device, destRack, { preserveL01: requiredU === 10 });
      if (dest) {
        const action = {
          type: "move_device",
          device_id: device.id,
          rack_id: dest.rack_id,
          layer_id: dest.layer_id,
          start_u: dest.start_u,
          u_size: device.u_size,
          source_rack_id: device.rack_id,
          source_layer_id: device.layer_id,
          source_start_u: device.start_u,
          source_u_size: device.u_size,
        };
        moveActions.push(action);
        movedOrigins.push({ device_id: device.id, rack_id: device.rack_id, layer_id: device.layer_id, start_u: device.start_u });
        try {
          applyMoveInPlace(action);
        } catch {
          allEvacuated = false;
          break;
        }
        placed = true;
        break;
      }
    }
    if (!placed) {
      allEvacuated = false;
      break;
    }
  }

  if (!allEvacuated) return null;

  const targets = intervalsFor(projected, rack, requiredU, requiredU === 10 ? {} : { allowNonL01: true });
  if (targets.length === 0) return null;

  return { moveActions, movedOrigins, target: targets[0], projected };
}

function tryL01Evacuation(state, request, serverRacks) {
  const requiredU = Number(request.u_size);
  const candidates = [];

  for (const rack of serverRacks) {
    const freeDirect = intervalsFor(state, rack, requiredU, requiredU === 10 ? {} : { allowNonL01: true });
    if (freeDirect.length > 0) continue;

    const result = tryEvacuateLayer(state, rack, "L01", requiredU, serverRacks);
    if (!result) continue;

    const placeAction = {
      type: "place_device",
      rack_id: result.target.rack_id,
      layer_id: result.target.layer_id,
      start_u: result.target.start_u,
      device: makeDevice(request, 0, result.target.start_u),
    };

    const allActions = [...result.moveActions, placeAction];
    const validation = evaluateActions(state, allActions);
    if (!validation.allowed) continue;

    candidates.push({
      id: `L01EVAC-${rack.id}`,
      rack_id: result.target.rack_id,
      layer_id: result.target.layer_id,
      actions: allActions,
      validation,
      risk: "warning",
      optimization_type: "l01_evacuation",
      moveCount: result.moveActions.length,
      impact: {
        ...movedImpactMeta(state, result.movedOrigins.map((m) => m.device_id)),
        optimization: `清空${rack.id}的L01层，迁移所有设备腾出10U连续空间`,
        devices_moved: result.moveActions.length,
        migrated_devices: result.movedOrigins.map((m) => m.device_id),
        steps: [
          ...result.moveActions.map((a) => {
            const origin = result.movedOrigins.find((m) => m.device_id === a.device_id);
            const device = state.devices.find((d) => d.id === a.device_id);
            const size = device?.u_size;
            const targetText = `${a.rack_id} / ${a.layer_id} / ${uIntervalText(a.start_u, size)}`;
            if (origin) {
              const originText = `${origin.rack_id} / ${origin.layer_id} / ${uIntervalText(origin.start_u, size)}`;
              return `迁移 ${a.device_id} [${originText}] → ${targetText}`;
            }
            return `迁移 ${a.device_id} → ${targetText}`;
          }),
          `放置新设备 ${request.id} 到 ${result.target.rack_id} L01 ${uIntervalText(result.target.start_u, request.u_size)}`,
          "验证电源、网络、业务健康",
        ],
        rollback_actions: result.moveActions.map((a) => {
          const origin = result.movedOrigins.find((m) => m.device_id === a.device_id);
          const device = state.devices.find((d) => d.id === a.device_id);
          return {
            type: "move_device",
            device_id: a.device_id,
            rack_id: origin?.rack_id ?? device?.rack_id,
            layer_id: origin?.layer_id ?? device?.layer_id,
            start_u: origin?.start_u ?? device?.start_u,
            source_rack_id: a.rack_id,
            source_layer_id: a.layer_id,
            source_start_u: a.start_u,
            source_u_size: device?.u_size,
          };
        }),
      },
    });
  }
  return candidates;
}

function tryDirectPlace(state, request, index, serverRacks) {
  const sizeU = Number(request.u_size);
  for (const rack of serverRacks) {
    const intervals = intervalsFor(state, rack, sizeU, sizeU === 10 ? { preferL01: true } : { allowNonL01: true });
    if (intervals.length > 0) {
      const target = intervals[0];
      const action = {
        type: "place_device",
        rack_id: target.rack_id,
        layer_id: target.layer_id,
        start_u: target.start_u,
        device: makeDevice(request, index, target.start_u),
      };
      try {
        const projected = applyActions(state, [action]);
        return { action, projected, target, rack };
      } catch {
        continue;
      }
    }
  }
  return null;
}

function tryMultiDevicePlan(state, request, serverRacks) {
  const count = Number(request.count ?? 1);
  if (count <= 1) return [];

  const candidates = [];
  const requiredU = Number(request.u_size);

  // 10U 大批量（>8 台）使用组合优化，避免 DFS 组合爆炸
  if (requiredU === 10 && count > 8) {
    return tryBulkTenUPlan(state, request, serverRacks);
  }

  // 非 10U 大批量：直接放置层已通过贪心策略处理，
  // 若仍无可行方案，说明当前空闲容量或碎片化问题无法通过 DFS 解决；
  // 继续 DFS 只会无意义地截断在 8 台，直接返回空避免误导。
  if (requiredU !== 10 && count > 8) {
    return [];
  }

  // 小批量使用 DFS（已限制分支）
  const plans = [];
  const maxDepth = Math.min(count, 8);

  function searchPlan(currentState, actions, placedIndexes, remainingIndexes, depth, usedRacks) {
    if (plans.length >= 8) return;
    if (depth > maxDepth) return;
    if (remainingIndexes.length === 0) {
      const validation = evaluateActions(state, actions);
      if (validation.allowed) {
        const lastPlaceAction = [...actions].reverse().find((a) => a.type === "place_device");
        plans.push({
          actions,
          rack_id: lastPlaceAction?.rack_id,
          layer_id: lastPlaceAction?.layer_id,
          placedCount: placedIndexes.length,
          validation,
        });
      }
      return;
    }

    const nextIndex = remainingIndexes[0];
    const nextRemaining = remainingIndexes.slice(1);

    const direct = tryDirectPlace(currentState, request, nextIndex, serverRacks);
    if (direct && (requiredU !== 10 || !usedRacks.has(direct.rack.id))) {
      searchPlan(
        direct.projected,
        [...actions, direct.action],
        [...placedIndexes, nextIndex],
        nextRemaining,
        depth + 1,
        requiredU === 10 ? new Set([...usedRacks, direct.rack.id]) : usedRacks,
      );
      if (plans.length >= 8) return;
    }

    if (requiredU === 10) {
      let racksTried = 0;
      const maxEvacuationRacks = 3;
      const racksWithL01Occupied = serverRacks.filter((rack) => {
        if (usedRacks.has(rack.id)) return false;
        return currentState.devices.some(
          (d) => d.rack_id === rack.id && d.layer_id === "L01" && d.status !== "cancelled",
        );
      });
      for (const rack of racksWithL01Occupied) {
        if (racksTried >= maxEvacuationRacks) break;
        const evacResult = tryEvacuateLayer(currentState, rack, "L01", requiredU, serverRacks);
        if (!evacResult) continue;
        racksTried += 1;
        const placeAction = {
          type: "place_device",
          rack_id: evacResult.target.rack_id,
          layer_id: evacResult.target.layer_id,
          start_u: evacResult.target.start_u,
          device: makeDevice(request, nextIndex, evacResult.target.start_u),
        };
        const allActions = [...actions, ...evacResult.moveActions, placeAction];
        let projected;
        try {
          projected = applyActions(currentState, [...evacResult.moveActions, placeAction]);
        } catch {
          continue;
        }
        searchPlan(projected, allActions, [...placedIndexes, nextIndex], nextRemaining, depth + 1, new Set([...usedRacks, rack.id]));
        if (plans.length >= 8) return;
      }
    }
  }

  searchPlan(state, [], [], Array.from({ length: count }, (_, i) => i), 0, new Set());

  for (const plan of plans.slice(0, 8)) {
    candidates.push(buildMultiDeviceCandidate(state, request, plan.actions, count));
  }

  return candidates;
}

function buildMultiDeviceCandidate(state, request, actions, count) {
  const moveActions = actions.filter((a) => a.type === "move_device");
  const placeActions = actions.filter((a) => a.type === "place_device");
  const deviceIds = [...new Set(moveActions.map((a) => a.device_id))];
  const validation = evaluateActions(state, actions);

  const placeSignature = placeActions.map((a) => `${a.rack_id}-${a.start_u}`).join("_");
  return {
    id: `MULTI-${placeSignature}-${deviceIds.join("-") || "direct"}`,
    rack_id: placeActions[placeActions.length - 1].rack_id,
    layer_id: placeActions[placeActions.length - 1].layer_id,
    actions,
    validation,
    risk: moveActions.length > 0 ? "warning" : "safe",
    optimization_type: moveActions.length > 0 ? "multi_device_with_migration" : "multi_device_direct",
    impact: {
      ...movedImpactMeta(state, deviceIds),
      optimization: moveActions.length > 0
        ? `批量部署${count}台设备：直接放置${Math.max(0, count - deviceIds.length)}台，迁移${deviceIds.length}台设备腾出空间`
        : `批量部署${count}台设备，均有直接可用空间`,
      devices_moved: deviceIds.length,
      migrated_devices: deviceIds,
      steps: [
        ...moveActions.map((a) => {
          const original = state.devices.find((d) => d.id === a.device_id);
          const size = original?.u_size;
          const targetText = `${a.rack_id} / ${a.layer_id} / ${uIntervalText(a.start_u, size)}`;
          if (original) {
            const originalText = `${original.rack_id} / ${original.layer_id} / ${uIntervalText(original.start_u, size)}`;
            return `迁移 ${a.device_id} [${originalText}] → ${targetText}`;
          }
          return `迁移 ${a.device_id} → ${targetText}`;
        }),
        ...placeActions.map((a) => `放置 ${a.device.id} 到 ${a.rack_id} / ${a.layer_id} / ${uIntervalText(a.start_u, a.device?.u_size)}`),
        "验证电源、网络、业务健康",
      ],
      rollback_actions: moveActions.map((a) => {
        const original = state.devices.find((d) => d.id === a.device_id);
        if (!original) return null;
        return {
          type: "move_device",
          device_id: a.device_id,
          rack_id: original.rack_id,
          layer_id: original.layer_id,
          start_u: original.start_u,
          source_rack_id: a.rack_id,
          source_layer_id: a.layer_id,
          source_start_u: a.start_u,
          source_u_size: original.u_size,
        };
      }).filter(Boolean),
    },
  };
}

function rackEvacuationCost(state, rack, result) {
  const l01Devices = state.devices.filter(
    (d) => d.rack_id === rack.id && d.layer_id === "L01" && d.status !== "cancelled",
  );
  const hasTenU = l01Devices.some((d) => Number(d.u_size) === 10);
  const crossRackMoves = result.moveActions.filter((a) => a.rack_id !== rack.id).length;
  const sameRackMoves = result.moveActions.length - crossRackMoves;
  // 代价权重：跨柜迁移 >> 同柜迁移 > 含 10U 设备 > 设备数量 > 总占用 U 数
  return (
    crossRackMoves * 100 +
    sameRackMoves * 20 +
    (hasTenU ? 500 : 0) +
    l01Devices.length * 5 +
    l01Devices.reduce((sum, d) => sum + Number(d.u_size), 0)
  );
}

function tryBulkTenUPlan(state, request, serverRacks) {
  const count = Number(request.count ?? 1);
  const candidates = [];

  // 1. 直接可用 L01 机柜
  const directSlots = serverRacks
    .map((rack) => {
      const intervals = intervalsFor(state, rack, 10, {});
      return intervals.length > 0 ? { rack, target: intervals[0], cost: 0 } : null;
    })
    .filter(Boolean);

  // 2. 可迁移腾空的 L01 机柜，预计算独立代价
  const evacSlots = [];
  for (const rack of serverRacks) {
    if (directSlots.some((s) => s.rack.id === rack.id)) continue;
    const l01Devices = state.devices.filter(
      (d) => d.rack_id === rack.id && d.layer_id === "L01" && d.status !== "cancelled",
    );
    if (l01Devices.length === 0) continue;
    if (!l01Devices.every((d) => !eligibilityReason(d))) continue;

    const result = tryEvacuateLayer(state, rack, "L01", 10, serverRacks);
    if (!result) continue;

    evacSlots.push({
      rack,
      result,
      cost: rackEvacuationCost(state, rack, result),
    });
  }

  // 3. 直接可用机柜足够，走最快路径
  if (directSlots.length >= count) {
    const actions = [];
    for (let i = 0; i < count; i++) {
      const { target } = directSlots[i];
      actions.push({
        type: "place_device",
        rack_id: target.rack_id,
        layer_id: target.layer_id,
        start_u: target.start_u,
        device: makeDevice(request, i, target.start_u),
      });
    }
    const validation = evaluateActions(state, actions);
    if (validation.allowed) {
      candidates.push(buildMultiDeviceCandidate(state, request, actions, count));
    }
    return candidates;
  }

  const neededDirect = Math.min(directSlots.length, count);
  const neededEvacuate = count - neededDirect;

  if (neededEvacuate > evacSlots.length) return [];

  // 4. 按独立代价排序，优先选择迁移代价低的机柜
  evacSlots.sort((a, b) => a.cost - b.cost);

  // 5. 顺序投影构建动作序列，动态重新计算迁移目标，避免目标冲突
  function buildActions(directSelection, evacSelection) {
    let projected = structuredClone(state);
    const actions = [];
    let deviceIndex = 0;

    for (const { target } of directSelection) {
      const placeAction = {
        type: "place_device",
        rack_id: target.rack_id,
        layer_id: target.layer_id,
        start_u: target.start_u,
        device: makeDevice(request, deviceIndex, target.start_u),
      };
      actions.push(placeAction);
      projected = applyActions(projected, [placeAction]);
      deviceIndex += 1;
    }

    for (const { rack } of evacSelection) {
      const evacResult = tryEvacuateLayer(projected, rack, "L01", 10, serverRacks);
      if (!evacResult) return null;
      const placeAction = {
        type: "place_device",
        rack_id: evacResult.target.rack_id,
        layer_id: evacResult.target.layer_id,
        start_u: evacResult.target.start_u,
        device: makeDevice(request, deviceIndex, evacResult.target.start_u),
      };
      actions.push(...evacResult.moveActions, placeAction);
      projected = applyActions(projected, [...evacResult.moveActions, placeAction]);
      deviceIndex += 1;
    }

    return actions;
  }

  const baseDirect = directSlots.slice(0, neededDirect);
  const baseEvac = evacSlots.slice(0, neededEvacuate);

  // 6. 基础方案（贪心最低代价）
  const baseActions = buildActions(baseDirect, baseEvac);
  if (baseActions) {
    const baseValidation = evaluateActions(state, baseActions);
    if (baseValidation.allowed) {
      candidates.push(buildMultiDeviceCandidate(state, request, baseActions, count));
    }
  }

  // 7. 全局优化变体：在候选池中做局部搜索
  // 候选池取 neededEvacuate + 10，平衡解空间与性能
  const poolSize = Math.min(evacSlots.length, neededEvacuate + 10);
  const pool = evacSlots.slice(0, poolSize);

  let variantCount = 0;
  const maxVariants = 15; // 与基础方案合计不超过 16 个候选

  // 7.1 单点替换：用一个未选机柜替换已选机柜
  for (let selectedIdx = 0; selectedIdx < neededEvacuate && variantCount < maxVariants; selectedIdx++) {
    for (let poolIdx = neededEvacuate; poolIdx < poolSize && variantCount < maxVariants; poolIdx++) {
      const variantEvac = baseEvac.slice();
      variantEvac[selectedIdx] = pool[poolIdx];
      const actions = buildActions(baseDirect, variantEvac);
      if (!actions) continue;
      const validation = evaluateActions(state, actions);
      if (validation.allowed) {
        candidates.push(buildMultiDeviceCandidate(state, request, actions, count));
        variantCount += 1;
      }
    }
  }

  // 7.2 两两交换：在已选机柜内部调整顺序，探索不同投影路径
  // 当 neededEvacuate 较大时，可选机柜组合空间小，跳过交换以减少计算量
  if (neededEvacuate <= 12) {
    for (let i = 0; i < neededEvacuate && variantCount < maxVariants; i++) {
      for (let j = i + 1; j < neededEvacuate && variantCount < maxVariants; j++) {
        const variantEvac = baseEvac.slice();
        [variantEvac[i], variantEvac[j]] = [variantEvac[j], variantEvac[i]];
        const actions = buildActions(baseDirect, variantEvac);
        if (!actions) continue;
        const validation = evaluateActions(state, actions);
        if (validation.allowed) {
          candidates.push(buildMultiDeviceCandidate(state, request, actions, count));
          variantCount += 1;
        }
      }
    }
  }

  return candidates;
}

function devicesAffectedByDivider(state, rack, newDividers) {
  const newLayers = deriveLayers({ ...rack, dividers_u: newDividers });
  const layerMap = new Map(newLayers.map((l) => [l.id, l]));
  const rackDevices = state.devices.filter(
    (d) => d.rack_id === rack.id && d.status !== "cancelled" && d.status === "running",
  );
  const affected = [];
  for (const device of rackDevices) {
    const newLayer = layerMap.get(device.layer_id);
    if (!newLayer) {
      affected.push({ device, reason: "layer_missing" });
      continue;
    }
    const endU = Number(device.start_u) + Number(device.u_size) - 1;
    if (Number(device.start_u) < newLayer.start_u || endU > newLayer.end_u) {
      affected.push({ device, reason: "crosses_layer_boundary" });
      continue;
    }
    if (endU >= newLayer.reserve_start_u) {
      affected.push({ device, reason: "occupies_reserve" });
    }
  }
  return { affected, newLayers };
}

function tryDividerWithMigration(state, rack, request, serverRacks) {
  const requiredU = Number(request.u_size);
  if (requiredU === 10) return [];

  const candidates = [];
  const targetLayers = ["L02", "L03", "L04"];

  for (const targetLayer of targetLayers) {
    const neededU = requiredU + 2;
    const layerIdx = Number(targetLayer.slice(-1)) - 2;

    const possibleDividers = [];
    for (let d1 = 14; d1 <= 28; d1 += 1) {
      for (let d2 = d1 + 2; d2 <= 38; d2 += 1) {
        const layerSizes = [
          d1 - 12 - 2,
          d2 - d1 - 2,
          42 - d2 - 2,
        ];
        if (layerSizes.some((s) => s < 0)) continue;
        if (layerSizes[layerIdx] >= neededU) {
          possibleDividers.push([12, d1, d2]);
        }
      }
    }

    possibleDividers.sort((a, b) => {
      const origDiv = rack.dividers_u;
      const diffA = Math.abs(a[1] - origDiv[1]) + Math.abs(a[2] - origDiv[2]);
      const diffB = Math.abs(b[1] - origDiv[1]) + Math.abs(b[2] - origDiv[2]);
      return diffA - diffB;
    });

    for (const newDividers of possibleDividers.slice(0, 20)) {
      if (newDividers[0] === rack.dividers_u[0]
        && newDividers[1] === rack.dividers_u[1]
        && newDividers[2] === rack.dividers_u[2]) continue;

      const { affected, newLayers } = devicesAffectedByDivider(state, rack, newDividers);

      if (affected.length === 0) continue;

      const allMovable = affected.every(({ device }) => !eligibilityReason(device));
      if (!allMovable) continue;

      let projected = structuredClone(state);
      const moveActions = [];
      const movedOrigins = [];
      let canRelocate = true;

      for (const { device } of affected) {
        let placed = false;

        const otherLayersInRack = newLayers.filter((l) => l.id !== device.layer_id);
        for (const layer of otherLayersInRack) {
          const layerIntervals = intervalsFor(projected, rack, Number(device.u_size), { allowNonL01: true })
            .filter((i) => i.layer_id === layer.id);
          if (layerIntervals.length > 0) {
            const dest = layerIntervals[0];
            const action = {
              type: "move_device",
              device_id: device.id,
              rack_id: rack.id,
              layer_id: dest.layer_id,
              start_u: dest.start_u,
            };
            moveActions.push(action);
            movedOrigins.push({ device_id: device.id, rack_id: device.rack_id, layer_id: device.layer_id, start_u: device.start_u });
            try {
              projected = applyActions(projected, [action]);
            } catch {
              canRelocate = false;
              break;
            }
            placed = true;
            break;
          }
        }

        if (!placed) {
          const otherRacks = serverRacks.filter((r) => r.id !== rack.id);
          for (const destRack of otherRacks) {
            const dest = canMoveDeviceTo(projected, device, destRack, { preserveL01: false });
            if (dest) {
              const action = {
                type: "move_device",
                device_id: device.id,
                rack_id: dest.rack_id,
                layer_id: dest.layer_id,
                start_u: dest.start_u,
              };
              moveActions.push(action);
              movedOrigins.push({ device_id: device.id, rack_id: device.rack_id, layer_id: device.layer_id, start_u: device.start_u });
              try {
                projected = applyActions(projected, [action]);
              } catch {
                canRelocate = false;
                break;
              }
              placed = true;
              break;
            }
          }
        }

        if (!placed) {
          canRelocate = false;
          break;
        }
      }

      if (!canRelocate) continue;

      const dividerAction = { type: "set_dividers", rack_id: rack.id, dividers_u: newDividers };
      try {
        projected = applyActions(projected, [dividerAction]);
      } catch {
        continue;
      }

      const targetIntervals = intervalsFor(projected, rack, requiredU, { allowNonL01: true })
        .filter((i) => i.layer_id === targetLayer);
      if (targetIntervals.length === 0) continue;

      const target = targetIntervals[0];
      const placeAction = {
        type: "place_device",
        rack_id: target.rack_id,
        layer_id: target.layer_id,
        start_u: target.start_u,
        device: makeDevice(request, 0, target.start_u),
      };

      const allActions = [...moveActions, dividerAction, placeAction];
      const validation = evaluateActions(state, allActions);
      if (!validation.allowed) continue;

      candidates.push({
        id: `DIVMIG-${rack.id}-${targetLayer}-${newDividers.join("-")}`,
        rack_id: target.rack_id,
        layer_id: target.layer_id,
        actions: allActions,
        validation,
        risk: "warning",
        optimization_type: "divider_with_migration",
        moveCount: moveActions.length,
        impact: {
          optimization: `调整${rack.id}挡板位置并迁移受影响设备，为${targetLayer}层腾出${requiredU}U空间`,
          devices_moved: moveActions.length,
          new_dividers: newDividers,
          migrated_devices: movedOrigins.map((m) => m.device_id),
          steps: [
            ...moveActions.map((a) => {
              const orig = movedOrigins.find((m) => m.device_id === a.device_id);
              const sameRack = orig && orig.rack_id === a.rack_id;
              return sameRack
                ? `在${rack.id}内调整 ${a.device_id} 至 ${a.layer_id} U${a.start_u}`
                : `迁移 ${a.device_id} 至 ${a.rack_id} ${a.layer_id} U${a.start_u}`;
            }),
            `调整 ${rack.id} 挡板位置至 ${newDividers.join("/")}U`,
            `放置新设备 ${request.id} 到 ${target.rack_id} ${target.layer_id} U${target.start_u}`,
            "验证电源、网络、业务健康",
          ],
          rollback_actions: [
            ...movedOrigins.map((m) => ({
              type: "move_device",
              device_id: m.device_id,
              rack_id: m.rack_id,
              layer_id: m.layer_id,
              start_u: m.start_u,
            })),
            { type: "set_dividers", rack_id: rack.id, dividers_u: rack.dividers_u },
          ],
        },
      });

      if (candidates.length >= 4) break;
    }
    if (candidates.length >= 4) break;
  }

  return candidates;
}

function tryCompaction(state, rack, request) {
  const rackDevices = state.devices
    .filter((d) => d.rack_id === rack.id && d.status !== "cancelled" && d.status === "running")
    .sort((a, b) => Number(a.start_u) - Number(b.start_u));
  const layers = deriveLayers(rack);

  const actions = [];
  const projected = structuredClone(state);
  let canCompact = true;

  for (const layer of layers) {
    const layerDevices = rackDevices.filter((d) => d.layer_id === layer.id);
    if (layerDevices.length === 0) continue;

    const movableInLayer = layerDevices.filter((d) => !eligibilityReason(d));
    const fixedInLayer = layerDevices.filter((d) => eligibilityReason(d));

    if (fixedInLayer.length > 0 && movableInLayer.length > 0) {
      canCompact = false;
      break;
    }

    if (movableInLayer.length === layerDevices.length && layerDevices.length > 1) {
      let cursor = layer.start_u;
      for (const device of layerDevices) {
        if (Number(device.start_u) !== cursor) {
          actions.push({
            type: "move_device",
            device_id: device.id,
            rack_id: rack.id,
            layer_id: layer.id,
            start_u: cursor,
          });
          const projDevice = projected.devices.find((d) => d.id === device.id);
          if (projDevice) projDevice.start_u = cursor;
        }
        cursor += Number(device.u_size);
      }
    }
  }

  if (!canCompact || actions.length === 0) return null;

  const targets = intervalsFor(projected, rack, Number(request.u_size), { allowNonL01: true });
  if (targets.length === 0) return null;

  const target = targets[0];
  const placeAction = {
    type: "place_device",
    rack_id: target.rack_id,
    layer_id: target.layer_id,
    start_u: target.start_u,
    device: makeDevice(request, 0, target.start_u),
  };

  const allActions = [...actions, placeAction];
  const validation = evaluateActions(state, allActions);
  if (!validation.allowed) return null;

  return { actions: allActions, target, type: "compaction", moveCount: actions.length };
}

export function generateSpaceOptimizationCandidates(state, request, options = {}) {
  const validator = options.validator ?? evaluateActions;
  const maxCandidates = Math.max(1, Math.min(32, Number(options.maxCandidates) || 16));
  const candidates = [];
  const assessments = [];

  const serverRacks = state.racks.filter((rack) => rack.role === "server");
  const requiredU = Number(request.u_size);
  const count = Number(request.count ?? 1);

  if (count > 1) {
    const multiPlans = tryMultiDevicePlan(state, request, serverRacks);
    for (const plan of multiPlans) {
      if (plan.validation.allowed) {
        candidates.push(plan);
        if (candidates.length >= maxCandidates) break;
      }
    }
    return { candidates, assessments };
  }

  for (const rack of serverRacks) {
    const result = tryCompaction(state, rack, request);
    if (result) {
      candidates.push({
        id: `COMPACT-${rack.id}-${result.target.layer_id}-${result.target.start_u}`,
        rack_id: result.target.rack_id,
        layer_id: result.target.layer_id,
        actions: result.actions,
        validation: result.validation,
        risk: "warning",
        optimization_type: result.type,
        impact: {
          optimization: "同机柜设备压实整理",
          devices_moved: result.moveCount,
          steps: [
            `检查 ${rack.id} 各层设备布局`,
            ...result.actions.filter((a) => a.type === "move_device").map((a) =>
              `调整 ${a.device_id} 位置至 ${a.rack_id} ${a.layer_id} U${a.start_u}`),
            `放置新设备 ${request.id} 到 ${result.target.rack_id} ${result.target.layer_id} U${result.target.start_u}`,
            "验证电源、网络、业务健康",
          ],
          rollback_actions: result.actions.filter((a) => a.type === "move_device").map((a) => {
            const original = state.devices.find((d) => d.id === a.device_id);
            return original ? { type: "move_device", device_id: a.device_id, rack_id: original.rack_id, layer_id: original.layer_id, start_u: original.start_u } : null;
          }).filter(Boolean),
        },
      });
    }
  }

  for (const rack of serverRacks) {
    const dividerCandidates = tryDividerWithMigration(state, rack, request, serverRacks);
    for (const c of dividerCandidates) {
      candidates.push(c);
      if (candidates.length >= maxCandidates) break;
    }
    if (candidates.length >= maxCandidates) break;
  }

  if (requiredU === 10) {
    const l01EvacCandidates = tryL01Evacuation(state, request, serverRacks);
    for (const c of l01EvacCandidates) {
      candidates.push(c);
      if (candidates.length >= maxCandidates) break;
    }
  }

  return { candidates, assessments };
}
