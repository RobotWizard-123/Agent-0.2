import { evaluateActions, slimForPlanning } from "../domain/constraint-engine.js";
import {
  generateDividerCandidates,
  generateDirectPlacementCandidates,
  generatePlacementCandidates,
} from "./candidate-generator.js";
import { createCpSatAdapter } from "./cp-sat-adapter.js";
import { generateMigrationCandidates } from "./migration-planner.js";
import { generateSpaceOptimizationCandidates } from "./space-optimizer.js";
import { normalizePlacementCount } from "./placement-limits.js";
import { scoreCandidate } from "./strategy-scorer.js";
import { DEFAULT_STRATEGY_ID, strategyProfile } from "./strategy-profiles.js";

function normalizeRequest(request = {}) {
  return {
    ...structuredClone(request),
    id: request.id || "SRV-RECOMMEND",
    count: normalizePlacementCount(request.count),
    u_size: Number(request.u_size || 0),
    rated_power_w: Number(request.rated_power_w ?? request.power_w ?? 0),
    real_power_w: request.real_power_w ?? null,
    weight_kg: Number(request.weight_kg || 0),
    network_ports: Number(request.network_ports || 0),
    business_id: request.business_id ?? request.business ?? null,
    replica_group: request.replica_group ?? null,
    preferred_rack_ids: Array.isArray(request.preferred_rack_ids) ? request.preferred_rack_ids : [],
  };
}

function uniquePlacementRacks(actions) {
  return [...new Set(actions.filter((action) => action.type === "place_device").map((action) => action.rack_id))];
}

function sourceImbalance(state, projectedDevices) {
  const sources = new Map();
  for (const rack of state.racks.filter((item) => item.role === "server")) {
    const current = sources.get(rack.source_id) ?? { used: 0, capacity: 0 };
    current.capacity += Number(rack.design_power_w);
    current.used += projectedDevices
      .filter((device) => device.rack_id === rack.id && device.status !== "cancelled")
      .reduce((sum, device) => sum + Number(device.rated_power_w ?? 0), 0);
    sources.set(rack.source_id, current);
  }
  const ratios = [...sources.values()].map((source) => source.capacity > 0 ? source.used / source.capacity : 0);
  return ratios.length > 0 ? Math.max(...ratios) - Math.min(...ratios) : 0;
}

function candidateEvidence(state, request, candidate) {
  const rackIds = uniquePlacementRacks(candidate.actions);
  const snapshots = rackIds.map((rackId) => candidate.validation.after[rackId]).filter((item) => item && !item.invalid);
  const ratio = (usedKey, capacityKey) => snapshots.length > 0
    ? Math.max(...snapshots.map((snapshot) => Number(snapshot[capacityKey]) > 0
      ? Number(snapshot[usedKey]) / Number(snapshot[capacityKey])
      : 0))
    : 1;
  const existingBusinessRacks = new Set(state.devices
    .filter((device) => request.business_id && device.business_id === request.business_id && device.status !== "cancelled")
    .map((device) => device.rack_id));
  const existingBusinessSwitches = new Set(state.racks
    .filter((rack) => existingBusinessRacks.has(rack.id))
    .map((rack) => rack.network_switch_id));
  const businessMisses = request.business_id && existingBusinessRacks.size > 0
    ? rackIds.filter((rackId) => !existingBusinessRacks.has(rackId)).length / Math.max(1, rackIds.length)
    : 0;
  const linkMisses = request.business_id && existingBusinessSwitches.size > 0
    ? rackIds.filter((rackId) => {
      const rack = state.racks.find((item) => item.id === rackId);
      return !existingBusinessSwitches.has(rack?.network_switch_id);
    }).length / Math.max(1, rackIds.length)
    : 0;

  return {
    projected_ratios: {
      power: ratio("rated_power_used_w", "design_power_w"),
      u: ratio("used_u", "usable_u"),
      weight: ratio("used_weight_kg", "max_weight_kg"),
      ports: ratio("used_ports", "port_limit"),
    },
    largest_contiguous_u_after: snapshots.length > 0
      ? Math.min(...snapshots.map((snapshot) => Number(snapshot.largest_contiguous_u ?? 0)))
      : 0,
    activated_empty_rack: rackIds.some((rackId) => !state.devices.some((device) => device.rack_id === rackId && device.status !== "cancelled")),
    business_distance: businessMisses,
    link_distance: linkMisses,
    source_imbalance: sourceImbalance(state, candidate.validation.projected_devices ?? state.devices),
    migration_count: candidate.actions.filter((action) => action.type === "move_device").length,
    divider_count: candidate.actions.filter((action) => action.type === "set_dividers").length,
    operation_complexity: (() => {
      const moves = candidate.actions.filter((a) => a.type === "move_device").length;
      const dividers = candidate.actions.filter((a) => a.type === "set_dividers").length;
      if (moves === 0 && dividers === 0) return 0;
      if (moves === 0 && dividers > 0) return 1;
      if (moves > 0 && dividers === 0) return 2 + moves * 0.1;
      return 3 + moves * 0.1;
    })(),
  };
}

function candidateReasons(request, candidate) {
  const hasDivider = candidate.actions.some((action) => action.type === "set_dividers");
  const moveActions = candidate.actions.filter((action) => action.type === "move_device");
  const placeActions = candidate.actions.filter((action) => action.type === "place_device");
  const hasMigration = moveActions.length > 0;
  const reasons = [
    `输入参数：${request.u_size}U / ${request.rated_power_w}W / ${request.weight_kg}KG / ${request.network_ports}端口 × ${request.count}`,
  ];
  if (placeActions.length === 1) {
    reasons.push(`使用 ${candidate.rack_id} ${candidate.layer_id} 的真实连续空闲 U 位`);
  } else {
    const racks = [...new Set(placeActions.map((a) => a.rack_id))];
    reasons.push(`批量放置到 ${racks.join("、")} 等机柜`);
  }
  if (request.preferred_rack_ids.includes(candidate.rack_id)) reasons.push(`命中优选机柜 ${candidate.rack_id}`);
  if (candidate.optimization_type === "l01_evacuation") {
    reasons.push(`10U设备需L01层，清空L01层并迁移${moveActions.length}台设备到其他机柜腾出完整10U空间`);
  } else if (candidate.optimization_type === "divider_with_migration") {
    reasons.push(`空间紧张，调整挡板位置并迁移受影响的${moveActions.length}台设备（先迁走再调挡板），腾出目标层空间`);
  } else if (candidate.optimization_type === "multi_device_with_migration") {
    reasons.push(`批量部署${request.count}台：部分直接放置，迁移${moveActions.length}台设备腾出空间`);
  } else if (candidate.optimization_type === "multi_device_direct") {
    reasons.push(`批量部署${request.count}台，所有机柜均有直接可用空间`);
  } else if (candidate.optimization_type === "compaction") {
    reasons.push(`空间紧张，机柜内设备压实整理（调整${moveActions.length}台设备位置）腾出连续空间`);
  } else if (candidate.optimization_type === "divider_shuffle") {
    reasons.push(`空间紧张，调整挡板位置并重排层内设备（调整${moveActions.length}台）腾出空间`);
  } else if (candidate.optimization_type === "multi_migration") {
    reasons.push(`空间紧张，跨机柜迁移${moveActions.length}台可移动设备腾出连续空间`);
  } else if (candidate.optimization_type === "compact_then_migrate") {
    reasons.push(`空间紧张，机柜内压实+外迁设备组合方案（共调整${moveActions.length}台）腾出空间`);
  } else if (hasDivider) {
    reasons.push("调整可移动隔板后重新验证现有固定设备与预留区");
  } else if (hasMigration) {
    reasons.push("容量紧张，需要跨机柜迁移一台符合维护条件的设备");
  }
  return reasons;
}

export function scorePlanningCandidate(state, request, candidate, { strategyId = DEFAULT_STRATEGY_ID, weightMultipliers = {} } = {}) {
  const evidence = candidateEvidence(state, request, candidate);
  const scored = scoreCandidate(state, request, { ...candidate, evidence }, { strategyId, weightMultipliers });
  return {
    ...candidate,
    evidence,
    eligible: scored.eligible,
    reason_code: scored.reason_code,
    score: scored.score,
    baseline_score: candidate.baseline_score ?? scored.score,
    score_breakdown: scored.breakdown,
    weights: scored.weights,
    risk: candidate.actions.some((action) => action.type === "move_device") || candidate.validation.warnings.length > 0 ? "warning" : "safe",
    reasons: candidate.reasons ?? candidateReasons(request, candidate),
  };
}

function scoreCandidates(state, request, candidates, options) {
  return candidates.map((candidate) => scorePlanningCandidate(state, request, candidate, options));
}

export function createPlanningEngine({
  validator = evaluateActions,
  cpSatAdapter = createCpSatAdapter({ validator }),
} = {}) {
  return {
    recommend(state, rawRequest, options = {}) {
      const request = normalizeRequest(rawRequest);
      const strategyId = options.strategyId ?? DEFAULT_STRATEGY_ID;
      const limit = Math.max(1, Math.min(4, Number(options.limit) || 4));
      strategyProfile(strategyId);

      if (!Number.isInteger(request.u_size) || request.u_size <= 0 || request.u_size > 10) {
        return {
          request,
          strategy_id: strategyId,
          strategy_weights: strategyProfile(strategyId).weights,
          candidates: [],
          rejected_count: 1,
          rejection_summary: [{ code: "DEVICE_U_UNSUPPORTED", count: 1 }],
          migration_assessments: [],
          solver: {
            engine: "beam_search",
            status: "not_run",
            duration_ms: 0,
            candidate_count: 0,
            fallback_reason: null,
          },
        };
      }

      // 使用精简状态进行规划，只保留 racks/devices/connections 等必要字段，
      // 剔除 plans/audit/alarms 等历史累积数据，大幅减少 structuredClone 内存开销。
      const planningState = slimForPlanning(state);

      // 策略按操作复杂度从低到高依次尝试：
      // 1. CP-SAT 精确求解（全局最优）
      // 2. 直接放置（无任何调整，最简单）
      // 3. 纯挡板调整（挡板移动不影响现有设备，不迁服务器）
      // 4. 单设备迁移（迁1台设备，不调挡板）
      // 5. 空间优化器（设备压实/挡板+迁移/L01清空/多设备级联，最复杂）

      const cpSat = cpSatAdapter.solve(planningState, request, { strategyId });
      let solver = { ...cpSat.solver };

      // 按复杂度顺序收集候选，每层找到可行方案则优先使用（通过评分排序自动体现）
      let allCandidates = [];

      // Layer 1: CP-SAT候选（如果成功）
      if (cpSat.outcome === "success") {
        allCandidates = [...cpSat.candidates];
      }

      // Layer 2: 直接放置（无调整）+ 纯挡板调整（无设备冲突）
      const directCandidates = generateDirectPlacementCandidates(planningState, request, { maxBeams: 64, validator });
      const pureDividerCandidates = generateDividerCandidates(planningState, request, { maxBeams: 64, validator });
      allCandidates = [...allCandidates, ...directCandidates, ...pureDividerCandidates];

      let scored = scoreCandidates(planningState, request, allCandidates, {
        strategyId,
        weightMultipliers: options.weightMultipliers ?? {},
      });
      let accepted = scored
        .filter((candidate) => candidate.eligible)
        .sort((left, right) => left.score - right.score || left.id.localeCompare(right.id));

      // 确定使用的引擎：优先看最优候选来自哪一层
      let usedEngine = cpSat.outcome === "success" ? "cp_sat" : "beam_search";
      let usedStatus = cpSat.outcome === "success" ? "success" : cpSat.outcome;
      let usedFallback = null;

      if (accepted.length > 0) {
        const bestCandidate = accepted[0];
        const isCpSatCandidate = cpSat.outcome === "success" && cpSat.candidates.some((c) => c.id === bestCandidate.id);
        const isDirectOrDivider = !isCpSatCandidate;
        if (isDirectOrDivider) {
          usedEngine = cpSat.outcome === "unavailable" ? "beam_search" : "beam_search";
          if (cpSat.outcome === "success") {
            usedStatus = "fallback";
            usedFallback = "CP_SAT_VALIDATION_REJECTED";
          } else if (cpSat.outcome === "unavailable") {
            usedStatus = "fallback";
            usedFallback = cpSat.solver.fallback_reason ?? "CP_SAT_TIMEOUT";
          } else if (cpSat.outcome === "infeasible") {
            // CP-SAT判定不可行，但挡板/直接放置找到方案，保持infeasible状态
            usedStatus = "infeasible";
            usedFallback = null;
          }
        }
      }

      // Layer 3: 单设备跨机柜迁移（不调挡板）
      let migrationAssessments = [];
      if (accepted.length === 0) {
        const migration = generateMigrationCandidates(planningState, request, { maxCandidates: 32, validator });
        migrationAssessments = migration.assessments;
        if (migration.candidates.length > 0) {
          const migScored = scoreCandidates(planningState, request, migration.candidates, {
            strategyId,
            weightMultipliers: options.weightMultipliers ?? {},
          });
          const migAccepted = migScored
            .filter((candidate) => candidate.eligible)
            .sort((left, right) => left.score - right.score || left.id.localeCompare(right.id));
          if (migAccepted.length > 0) {
            scored = migScored;
            accepted = migAccepted;
            allCandidates = migration.candidates;
            usedEngine = "migration_planner";
            usedStatus = "optimized";
            usedFallback = "SINGLE_DEVICE_MIGRATION";
          }
        }
      }

      // Layer 4: 硬阻断前最后手段——空间优化器（设备压实/挡板+迁移/L01清空/多设备级联）
      if (accepted.length === 0) {
        const spaceOpt = generateSpaceOptimizationCandidates(planningState, request, { maxCandidates: 16, validator });
        if (spaceOpt.candidates.length > 0) {
          const optScored = scoreCandidates(planningState, request, spaceOpt.candidates, {
            strategyId,
            weightMultipliers: options.weightMultipliers ?? {},
          });
          const optAccepted = optScored
            .filter((candidate) => candidate.eligible)
            .sort((left, right) => left.score - right.score || left.id.localeCompare(right.id));
          if (optAccepted.length > 0) {
            scored = optScored;
            accepted = optAccepted;
            allCandidates = spaceOpt.candidates;
            usedEngine = "space_optimizer";
            usedStatus = "optimized";
            usedFallback = "SPACE_REORGANIZATION";
          }
        }
      }

      solver = {
        ...solver,
        engine: usedEngine,
        status: usedStatus,
        fallback_reason: usedFallback,
      };

      const rejectionSummary = accepted.length === 0
        ? [{ code: allCandidates.length > 0 ? "STRATEGY_INELIGIBLE" : "NO_CONTIGUOUS_INTERVAL", count: Math.max(1, allCandidates.length) }]
        : [];

      return {
        request,
        strategy_id: strategyId,
        strategy_weights: accepted[0]?.weights ?? strategyProfile(strategyId).weights,
        candidates: accepted.slice(0, limit),
        rejected_count: scored.length - accepted.length + (scored.length === 0 ? 1 : 0),
        rejection_summary: rejectionSummary,
        migration_assessments: migrationAssessments,
        solver: {
          ...solver,
          candidate_count: Math.min(4, accepted.length),
        },
      };
    },
  };
}
