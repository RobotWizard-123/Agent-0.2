import { spawnSync } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { getCpSatConfig } from "../config.js";
import { evaluateActions } from "../domain/constraint-engine.js";
import { buildCpSatProblem } from "./cp-sat-slots.js";
import { placementDevice } from "./candidate-generator.js";
import {
  MAX_CP_SAT_ASSIGNMENT_VARIABLES,
  normalizePlacementCount,
} from "./placement-limits.js";

const root = dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const defaultScriptPath = join(root, "solver", "cp_sat_solver.py");
const MAX_BUFFER = 2_000_000;
const MAX_VALIDATION_REJECTION_CODES = 4;
const STABLE_FAILURE_CODES = new Set([
  "CP_SAT_PYTHON_UNAVAILABLE",
  "CP_SAT_TIMEOUT",
  "CP_SAT_OUTPUT_TOO_LARGE",
  "CP_SAT_DEPENDENCY_MISSING",
  "CP_SAT_PROCESS_FAILED",
  "CP_SAT_OUTPUT_INVALID",
  "CP_SAT_CONTRACT_INVALID",
  "CP_SAT_UNKNOWN",
  "CP_SAT_VALIDATION_REJECTED",
  "CP_SAT_MODEL_TOO_LARGE",
  "CP_SAT_REQUEST_INVALID",
]);

function metadata(
  status,
  durationMs = 0,
  candidateCount = 0,
  fallbackReason = null,
  engine = "cp_sat",
  validationEvidence = null,
) {
  const result = {
    engine,
    status,
    duration_ms: Number(durationMs) || 0,
    candidate_count: candidateCount,
    fallback_reason: fallbackReason,
  };
  if (validationEvidence?.validation_rejected_count > 0) {
    result.validation_rejected_count = validationEvidence.validation_rejected_count;
    result.validation_rejection_summary = validationEvidence.validation_rejection_summary;
  }
  return result;
}

function unavailable(code, durationMs = 0, validationEvidence = null) {
  return {
    outcome: "unavailable",
    candidates: [],
    solver: metadata("fallback", durationMs, 0, code, "beam_search", validationEvidence),
  };
}

function processFailure(result) {
  if (result.error?.code === "ENOENT") return "CP_SAT_PYTHON_UNAVAILABLE";
  if (result.error?.code === "ETIMEDOUT") return "CP_SAT_TIMEOUT";
  if (result.error?.code === "ENOBUFS") return "CP_SAT_OUTPUT_TOO_LARGE";
  if (/No module named ['\"]ortools/i.test(result.stderr ?? "")) return "CP_SAT_DEPENDENCY_MISSING";
  return "CP_SAT_PROCESS_FAILED";
}

function stableFailureCode(code) {
  return STABLE_FAILURE_CODES.has(code) ? code : "CP_SAT_PROCESS_FAILED";
}

function stableValidationCode(value) {
  return typeof value === "string" && /^[A-Z][A-Z0-9_]{0,63}$/.test(value)
    ? value
    : "HARD_CONSTRAINT_BLOCKED";
}

function validationEvidence(rejected) {
  if (rejected.length === 0) return null;
  const counts = new Map();
  for (const candidate of rejected) {
    const codes = new Set((candidate.validation?.blockers ?? [])
      .slice(0, 16)
      .map((blocker) => stableValidationCode(blocker?.code)));
    if (codes.size === 0) codes.add("HARD_CONSTRAINT_BLOCKED");
    for (const code of codes) counts.set(code, (counts.get(code) ?? 0) + 1);
  }
  return {
    validation_rejected_count: rejected.length,
    validation_rejection_summary: [...counts]
      .sort(([left], [right]) => left.localeCompare(right))
      .slice(0, MAX_VALIDATION_REJECTION_CODES)
      .map(([code, count]) => ({ code, count })),
  };
}

function parseOutput(result) {
  if (result.error || result.status !== 0) {
    throw Object.assign(new Error("CP-SAT process failed"), { code: processFailure(result) });
  }
  try {
    return JSON.parse(result.stdout);
  } catch {
    throw Object.assign(new Error("CP-SAT output is not JSON"), { code: "CP_SAT_OUTPUT_INVALID" });
  }
}

function matchedSlot(problem, placement) {
  return problem.slots.find((slot) =>
    slot.rack_id === placement.rack_id
    && slot.layer_id === placement.layer_id
    && slot.start_u === placement.start_u);
}

function candidateFromOutput(state, request, problem, output, validator, index) {
  if (
    !output
    || typeof output !== "object"
    || Array.isArray(output)
    || !Number.isFinite(output.objective_value)
    || !Array.isArray(output.placements)
    || output.placements.length !== request.count
  ) {
    throw Object.assign(new Error("Candidate placement count is invalid"), { code: "CP_SAT_CONTRACT_INVALID" });
  }
  if (output.placements.some((placement) =>
    !placement
    || typeof placement !== "object"
    || Array.isArray(placement)
    || !Number.isInteger(placement.device_index)
    || typeof placement.rack_id !== "string"
    || typeof placement.layer_id !== "string"
    || !Number.isInteger(placement.start_u))) {
    throw Object.assign(new Error("Candidate placement fields are invalid"), { code: "CP_SAT_CONTRACT_INVALID" });
  }
  const indexes = new Set(output.placements.map((placement) => placement.device_index));
  if (indexes.size !== request.count || [...indexes].some((value) => value < 0 || value >= request.count)) {
    throw Object.assign(new Error("Candidate device indexes are invalid"), { code: "CP_SAT_CONTRACT_INVALID" });
  }
  const placements = [...output.placements].sort((left, right) => left.device_index - right.device_index);
  const actions = placements.map((placement) => {
    const slot = matchedSlot(problem, placement);
    if (!slot) throw Object.assign(new Error("Candidate references an unknown slot"), { code: "CP_SAT_CONTRACT_INVALID" });
    return {
      type: "place_device",
      rack_id: slot.rack_id,
      layer_id: slot.layer_id,
      start_u: slot.start_u,
      device: placementDevice(request, placement.device_index, slot.start_u),
    };
  });
  const validation = validator(state, actions);
  return {
    id: `CP-SAT-${String(index + 1).padStart(2, "0")}-${actions.map((action) => `${action.rack_id}-${action.layer_id}-${action.start_u}`).join("--")}`,
    rack_id: actions[0]?.rack_id ?? null,
    layer_id: actions[0]?.layer_id ?? null,
    actions,
    validation,
    cp_sat_objective: output.objective_value,
  };
}

export function createCpSatAdapter({
  config = getCpSatConfig(),
  validator = evaluateActions,
  runProcess = spawnSync,
  scriptPath = defaultScriptPath,
} = {}) {
  return {
    solve(state, request, { strategyId = "balanced_optimal" } = {}) {
      if (!config.enabled) {
        return {
          outcome: "unavailable",
          candidates: [],
          solver: metadata("disabled", 0, 0, null, "beam_search"),
        };
      }
      let count;
      try {
        count = normalizePlacementCount(request.count);
      } catch {
        return unavailable("CP_SAT_REQUEST_INVALID");
      }
      const problem = buildCpSatProblem(state, { ...request, count }, {
        strategyId,
        maxCandidates: 4,
        timeLimitMs: 2_000,
      });
      if (count * problem.slots.length > MAX_CP_SAT_ASSIGNMENT_VARIABLES) {
        return unavailable("CP_SAT_MODEL_TOO_LARGE");
      }
      let payload;
      let processDurationMs = 0;
      try {
        const serialized = JSON.stringify(problem);
        if (Buffer.byteLength(serialized, "utf8") > MAX_BUFFER) {
          return unavailable("CP_SAT_CONTRACT_INVALID");
        }
        const startedAt = performance.now();
        let result;
        try {
          result = runProcess(config.pythonPath, [scriptPath], {
            input: serialized,
            encoding: "utf8",
            timeout: config.timeoutMs,
            maxBuffer: MAX_BUFFER,
            windowsHide: true,
            shell: false,
          });
        } finally {
          processDurationMs = Math.max(0, Math.round(performance.now() - startedAt));
        }
        payload = parseOutput(result);
      } catch (error) {
        return unavailable(stableFailureCode(error.code), processDurationMs);
      }
      if (
        payload?.schema_version !== 1
        || payload.engine !== "cp_sat"
        || !["optimal", "feasible", "infeasible", "unknown"].includes(payload.status)
        || !Array.isArray(payload.candidates)
        || payload.candidates.length > 4
        || (payload.status === "infeasible" && payload.candidates.length !== 0)
      ) return unavailable("CP_SAT_CONTRACT_INVALID", payload?.duration_ms);
      if (payload.status === "infeasible") {
        return {
          outcome: "infeasible",
          candidates: [],
          solver: metadata("infeasible", payload.duration_ms, 0),
        };
      }
      if (payload.status === "unknown") {
        return unavailable(stableFailureCode(payload.error_code ?? "CP_SAT_UNKNOWN"), payload.duration_ms);
      }
      try {
        const converted = payload.candidates.map((candidate, index) =>
          candidateFromOutput(state, request, problem, candidate, validator, index));
        const signatures = converted.map((candidate) =>
          candidate.actions.map((action) =>
            `${action.device.id}:${action.rack_id}:${action.layer_id}:${action.start_u}`).join("|"));
        if (new Set(signatures).size !== signatures.length) {
          return unavailable("CP_SAT_CONTRACT_INVALID", payload.duration_ms);
        }
        const allowed = converted.filter((candidate) => candidate.validation.allowed);
        const rejected = converted.filter((candidate) => !candidate.validation.allowed);
        const evidence = validationEvidence(rejected);
        if (allowed.length === 0) {
          return unavailable("CP_SAT_VALIDATION_REJECTED", payload.duration_ms, evidence);
        }
        return {
          outcome: "success",
          candidates: allowed,
          solver: metadata(payload.status, payload.duration_ms, allowed.length, null, "cp_sat", evidence),
        };
      } catch (error) {
        return unavailable(stableFailureCode(error.code), payload.duration_ms);
      }
    },
  };
}
