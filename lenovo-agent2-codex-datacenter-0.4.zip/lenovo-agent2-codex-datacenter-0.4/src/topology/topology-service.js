function topologyError(code, message, details = {}) {
  return Object.assign(new Error(message), { code, ...details });
}

function node(type, id, label, source, details = {}) {
  return { type, id, label, source, details };
}

function deviceWithConnections(state, device) {
  const rack = state.racks.find((item) => item.id === device.rack_id) || null;
  const powerSource = rack ? state.power_sources.find((item) => item.id === rack.source_id) : null;
  const powerConnection = state.power_connections.find((item) => item.device_id === device.id) || null;
  const networkConnection = state.network_connections.find((item) => item.device_id === device.id) || null;
  const accessSwitch = networkConnection
    ? state.topology.network.access_switches.find((item) => item.id === networkConnection.switch_id)
    : null;

  const endU = device.start_u + device.u_size - 1;

  return {
    ...structuredClone(device),
    end_u: endU,
    u_position: `U${device.start_u}–U${endU}`,
    rack: rack ? {
      id: rack.id,
      name: rack.name,
      role: rack.role,
      source_id: rack.source_id,
      source_name: powerSource?.name ?? null,
    } : null,
    pdu: powerConnection ? {
      id: powerConnection.pdu_id,
      outlet: powerConnection.outlet,
      label: `${powerConnection.pdu_id} / ${powerConnection.outlet}`,
    } : null,
    switch_port: networkConnection ? {
      switch_id: networkConnection.switch_id,
      switch_name: accessSwitch?.name ?? networkConnection.switch_id,
      device_port: networkConnection.device_port,
      switch_port: networkConnection.switch_port,
      vlan: networkConnection.vlan,
    } : null,
  };
}

export function createTopologyService() {
  return {
    devicePath(state, deviceId) {
      const device = state.devices.find((item) => item.id === deviceId);
      if (!device) throw topologyError("DEVICE_NOT_FOUND", `Device does not exist: ${deviceId}`, { device_id: deviceId });
      const rack = state.racks.find((item) => item.id === device.rack_id);
      if (!rack) throw topologyError("RACK_NOT_FOUND", `Rack does not exist: ${device.rack_id}`, { rack_id: device.rack_id });

      const powerSource = state.power_sources.find((item) => item.id === rack.source_id);
      const powerConnection = state.power_connections.find((item) => item.device_id === deviceId);
      const networkConnection = state.network_connections.find((item) => item.device_id === deviceId);
      const accessSwitch = networkConnection
        ? state.topology.network.access_switches.find((item) => item.id === networkConnection.switch_id)
        : null;
      const missingFields = [];

      const power = [
        node("room", state.room.id, state.room.name, state.room.data_source),
        node("power_source", powerSource?.id ?? null, powerSource?.name ?? "配电来源未接入", powerSource?.data_source ?? "unknown", {
          calculated_load_w: powerSource?.calculated_load_w ?? null,
        }),
        node("rack", rack.id, rack.name, rack.data_source, { design_power_w: rack.design_power_w }),
      ];
      if (powerConnection) {
        power.push(node("pdu", powerConnection.pdu_id, `${powerConnection.pdu_id} / ${powerConnection.outlet}`, powerConnection.data_source, {
          outlet: powerConnection.outlet,
        }));
        power.push(node("device", device.id, device.hostname ?? device.id, device.data_source));
      } else {
        missingFields.push("power_connection");
        power.push(node("power_connection", null, "设备PDU插口未接入", "unknown"));
      }

      const network = [node("device", device.id, device.hostname ?? device.id, device.data_source)];
      if (networkConnection) {
        network.push(node("access_switch", accessSwitch?.id ?? networkConnection.switch_id, accessSwitch?.name ?? networkConnection.switch_id, networkConnection.data_source, {
          device_port: networkConnection.device_port,
          switch_port: networkConnection.switch_port,
          vlan: networkConnection.vlan,
        }));
        network.push(node("core_switch", state.topology.network.core.id, state.topology.network.core.name, state.topology.network.core.data_source));
        network.push(node("external_uplink", null, state.topology.network.external_uplink.label, state.topology.network.external_uplink.data_source));
      } else {
        missingFields.push("network_connection");
        network.push(node("network_connection", null, "交换机端口未接入", "unknown"));
      }

      return {
        device: structuredClone(device),
        rack: structuredClone(rack),
        power,
        network,
        redundancy: "unverified",
        missing_fields: missingFields,
      };
    },

    rackDevices(state, rackId) {
      const rack = state.racks.find((item) => item.id === rackId);
      if (!rack) throw topologyError("RACK_NOT_FOUND", `Rack does not exist: ${rackId}`, { rack_id: rackId });

      const powerSource = state.power_sources.find((item) => item.id === rack.source_id) || null;
      const accessSwitchId = rack.network_switch_id;
      const accessSwitch = accessSwitchId
        ? state.topology.network.access_switches.find((item) => item.id === accessSwitchId)
        : null;

      const devices = state.devices
        .filter((device) => device.rack_id === rackId && device.status !== "cancelled")
        .sort((a, b) => a.start_u - b.start_u || a.id.localeCompare(b.id))
        .map((device) => deviceWithConnections(state, device));

      return {
        kind: "rack_devices",
        rack: {
          id: rack.id,
          name: rack.name,
          role: rack.role,
          height_u: rack.height_u,
          dividers_u: rack.dividers_u,
          design_power_w: rack.design_power_w,
          max_weight_kg: rack.max_weight_kg,
          network_port_limit: rack.network_port_limit,
          pdu_ids: rack.pdu_ids,
          source_id: rack.source_id,
          source_name: powerSource?.name ?? null,
          network_switch_id: accessSwitchId,
          network_switch_name: accessSwitch?.name ?? null,
          floor_position: rack.floor_position,
          data_source: rack.data_source,
        },
        devices,
        device_count: devices.length,
      };
    },

    searchDevices(state, query) {
      const q = String(query || "").trim().toUpperCase();
      if (!q) {
        return { kind: "device_search", query: "", matches: [] };
      }

      // 精确匹配 ID 优先
      const exactById = state.devices.find((device) =>
        device.status !== "cancelled" && device.id.toUpperCase() === q);
      if (exactById) {
        return {
          kind: "device_search",
          query,
          matches: [deviceWithConnections(state, exactById)],
          exact: true,
        };
      }

      // 模糊匹配 ID、it_code、hostname、asset_id、model、business
      const matches = state.devices
        .filter((device) => device.status !== "cancelled")
        .filter((device) => {
          const fields = [
            device.id,
            device.it_code,
            device.hostname,
            device.asset_id,
            device.model,
            device.business,
            device.serial,
            device.ip,
          ].filter(Boolean).map((f) => String(f).toUpperCase());
          return fields.some((field) => field.includes(q));
        })
        .sort((a, b) => {
          // 机柜内按 U 位排序，跨机柜按机柜 ID+U 位
          if (a.rack_id !== b.rack_id) return a.rack_id.localeCompare(b.rack_id);
          return a.start_u - b.start_u;
        })
        .slice(0, 20)
        .map((device) => deviceWithConnections(state, device));

      return { kind: "device_search", query, matches, exact: false };
    },
  };
}
