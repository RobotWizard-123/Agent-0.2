export function registerHealthRoutes(router, { repository, telemetryProvider, agentGateway }) {
  router.add("GET", "/health/live", () => ({ status: "live", application_version: "0.2.0" }));

  router.add("GET", "/health/ready", async () => {
    repository.read();
    const collector = typeof telemetryProvider?.health === "function"
      ? await telemetryProvider.health()
      : { status: "not_connected" };
    return {
      status: "ready",
      core: { repository: "ready" },
      dependencies: {
        model: agentGateway ? "configured" : "not_configured",
        collector: collector.status ?? "unknown",
      },
    };
  });
}
