import { createDemoState } from './src/demo-state.js';
import { createPlanningEngine } from './src/planning/planning-engine.js';

const state = createDemoState();
for (const d of state.devices) {
  if (d.layer_id === 'L01' && d.rack_id === 'CAB-01') {
    d.status = 'cancelled';
  } else if (d.layer_id === 'L01') {
    d.movable = true;
    d.criticality = 'normal';
    d.maintenance_window = 'Saturday 02:00-04:00';
  }
}

const engine = createPlanningEngine();
for (const count of [5, 10, 15, 20, 25]) {
  const start = Date.now();
  const result = engine.recommend(state, { id: 'TEST-10U', count, u_size: 10, rated_power_w: 1800, weight_kg: 42, network_ports: 2 });
  console.log('count=' + count, 'time=' + (Date.now() - start) + 'ms', 'candidates=' + result.candidates.length, 'solver=' + result.solver.engine + '/' + result.solver.status);
  if (result.candidates.length > 0) {
    const best = result.candidates[0];
    console.log('  moves=' + best.actions.filter(a => a.type === 'move_device').length, 'places=' + best.actions.filter(a => a.type === 'place_device').length);
  }
}
