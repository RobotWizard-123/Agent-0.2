import { createDemoState } from "../src/demo-state.js";
import { generateSpaceOptimizationCandidates } from "../src/planning/space-optimizer.js";
import { actionText } from "../public/js/views/placement-plan.js";

const state = createDemoState();
const request = {
  id: "SRV-LEADER-DEMO",
  it_code: "IT-LEADER",
  count: 2,
  u_size: 10,
  rated_power_w: 3500,
  weight_kg: 120,
  network_ports: 4,
  preferred_rack_ids: [],
};

const { candidates } = generateSpaceOptimizationCandidates(state, request, { maxCandidates: 4 });
const candidate = candidates[0];
const context = { devices: state.devices, racks: state.racks };

console.log("=== actionText for plan.actions ===");
for (const action of candidate.actions) {
  console.log(actionText(action, context));
  if (action.type === "move_device") {
    const found = state.devices.find((d) => d.id === action.device_id);
    console.log(`  device_id=${action.device_id} found=${!!found} u_size=${found?.u_size} action.u_size=${action.u_size}`);
  }
}
