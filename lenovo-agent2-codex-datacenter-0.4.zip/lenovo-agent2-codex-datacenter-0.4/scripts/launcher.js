// scripts/launcher.js
// 一键启动辅助脚本：检查环境、启动服务、检测端口、打开浏览器
import { spawn, exec, execSync } from 'child_process';
import { existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import net from 'net';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = join(__dirname, '..');
const PORT = 3000;
const URL = `http://127.0.0.1:${PORT}`;
const MAX_WAIT_MS = 30000;

const log = (msg) => console.log(`[启动器] ${msg}`);
const error = (msg) => console.error(`[错误] ${msg}`);
const warn = (msg) => console.warn(`[警告] ${msg}`);
const info = (msg) => console.log(`      ${msg}`);

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 检查端口是否被占用
function isPortInUse(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once('error', (err) => {
      if (err.code === 'EADDRINUSE') resolve(true);
      else resolve(false);
    });
    server.once('listening', () => {
      server.close();
      resolve(false);
    });
    server.listen(port, '127.0.0.1');
  });
}

// 检查端口是否正在监听（服务已启动）
function isPortListening(port) {
  return new Promise((resolve) => {
    const client = net.createConnection({ port, host: '127.0.0.1' }, () => {
      client.end();
      resolve(true);
    });
    client.on('error', () => resolve(false));
    client.setTimeout(2000, () => {
      client.destroy();
      resolve(false);
    });
  });
}

// 获取占用端口的进程 ID
async function getPortPID(port) {
  try {
    const result = execSync(`netstat -ano | findstr ":${port} " | findstr LISTENING`, { encoding: 'utf8' }).trim();
    if (result) {
      const parts = result.split(/\s+/).filter(Boolean);
      return parts[parts.length - 1];
    }
  } catch (_) { /* ignore */ }
  return null;
}

// 使用默认浏览器打开 URL
function openBrowser(url) {
  const platform = process.platform;
  try {
    if (platform === 'win32') {
      execSync(`start "" "${url}"`, { stdio: 'ignore' });
    } else if (platform === 'darwin') {
      execSync(`open "${url}"`, { stdio: 'ignore' });
    } else {
      execSync(`xdg-open "${url}"`, { stdio: 'ignore' });
    }
    return true;
  } catch (e) {
    return false;
  }
}

async function main() {
  console.log('');
  console.log('============================================================');
  console.log('  机房智能管理 Agent V0.2 - 一键启动');
  console.log('============================================================');
  console.log('');

  // 1. 检查 node_modules
  log('[1/5] 检查项目依赖...');
  const nodeModulesPath = join(PROJECT_ROOT, 'node_modules');
  if (!existsSync(nodeModulesPath)) {
    info('node_modules 目录不存在，正在执行 npm install...');
    try {
      execSync('npm install', { cwd: PROJECT_ROOT, stdio: 'inherit' });
      info('依赖安装完成。');
    } catch (e) {
      error('依赖安装失败！请检查网络连接后重试。');
      process.exit(1);
    }
  } else {
    info('依赖已就绪。');
  }

  // 2. 重置演示数据
  log('[2/5] 重置演示数据...');
  try {
    execSync('npm run reset:demo', { cwd: PROJECT_ROOT, stdio: 'ignore' });
    info('演示数据已重置为标准种子。');
  } catch (_) {
    warn('数据重置失败，将尝试继续启动...');
  }

  // 3. 清理端口占用
  log('[3/5] 检查端口状态...');
  const inUse = await isPortInUse(PORT);
  if (inUse) {
    const pid = await getPortPID(PORT);
    if (pid) {
      info(`检测到端口 ${PORT} 已被占用 (PID: ${pid})，正在关闭...`);
      try {
        execSync(`taskkill /F /PID ${pid}`, { stdio: 'ignore' });
        await sleep(2000);
        info('已清理占用端口的进程。');
      } catch (_) {
        warn(`无法关闭 PID ${pid}，请手动处理。`);
      }
    } else {
      info(`端口 ${PORT} 被占用，但无法定位进程 ID。`);
    }
  } else {
    info(`端口 ${PORT} 空闲。`);
  }

  // 4. 启动服务（新窗口，保留日志）
  log('[4/5] 启动服务...');
  console.log('');
  console.log('------------------------------------------------------------');
  console.log(`  服务地址:  ${URL}`);
  console.log('  管理员账号: admin / admin123');
  console.log('  查看者账号: viewer / viewer123');
  console.log('');
  console.log('  提示: 新弹出的"服务日志"窗口关闭时，服务也将停止');
  console.log('------------------------------------------------------------');
  console.log('');

  // Windows 下启动一个新的 cmd 窗口运行服务
  const isWin = process.platform === 'win32';
  if (isWin) {
    // 注意：路径必须加双引号，避免含空格或中文字符时报错
    const serverCmd = `start "Service Log" cmd /k "cd /d ""${PROJECT_ROOT}"" && npm start"`;
    exec(serverCmd, { windowsHide: false }, (err) => {
      if (err) warn(`启动服务窗口失败: ${err.message}`);
    });
  } else {
    // 非 Windows：直接后台启动
    const child = spawn('npm', ['start'], {
      cwd: PROJECT_ROOT,
      detached: true,
      stdio: 'inherit',
    });
    child.unref();
  }

  // 5. 等待服务启动并打开浏览器
  log('[5/5] 等待服务启动...');
  const startTime = Date.now();
  let success = false;

  while (Date.now() - startTime < MAX_WAIT_MS) {
    const listening = await isPortListening(PORT);
    if (listening) {
      success = true;
      break;
    }
    process.stdout.write('.');
    await sleep(1000);
  }
  process.stdout.write('\n');

  if (success) {
    log('服务启动成功！正在打开浏览器...');
  } else {
    warn('等待超时，可能服务尚未完全启动。仍将尝试打开浏览器...');
    warn('请检查弹出的"服务日志"窗口是否有错误信息。');
  }

  const opened = openBrowser(URL);
  if (opened) {
    info('浏览器已启动。');
  } else {
    warn('无法自动打开浏览器，请手动访问: ' + URL);
  }

  console.log('');
  console.log('完成！可手动访问: ' + URL);
  console.log('');

  // 等待 3 秒后退出启动器（不影响服务窗口）
  await sleep(3000);
  process.exit(0);
}

main().catch(err => {
  error('启动过程发生异常:');
  console.error(err);
  process.exit(1);
});
