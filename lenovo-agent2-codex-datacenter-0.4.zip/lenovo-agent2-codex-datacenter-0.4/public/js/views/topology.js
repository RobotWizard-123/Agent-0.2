import {
  detailList,
  emptyState,
  formatPower,
  h,
  panel,
  showToast,
  sourceBadge,
  statusBadge,
} from "../components.js";
import { loadTopology } from "../state.js";

async function queryTopology(id) {
  try {
    await loadTopology(id);
  } catch (error) {
    showToast(`${error.code ?? "TOPOLOGY_FAILED"} · ${error.message}`, "danger");
  }
}

function queryButton(id, label, children, className = "aggregate-node") {
  return h("button", {
    type: "button",
    className,
    "aria-label": label,
    onClick: () => queryTopology(id),
  }, children);
}

function pathNode(node, index, total) {
  return h("div", { className: "path-segment" }, [
    h("article", { className: `path-node node-${node.type}` }, [
      h("div", { className: "path-node-head" }, [h("span", { text: node.type }), sourceBadge(node.source)]),
      h("strong", { text: node.label ?? node.id ?? "未知节点" }),
      h("code", { text: node.id ?? "UNKNOWN" }),
      Object.keys(node.details ?? {}).length ? h("small", { text: Object.entries(node.details).map(([key, value]) => `${key}: ${value}`).join(" · ") }) : null,
    ]),
    index < total - 1 ? h("span", { className: "path-link", "aria-hidden": "true" }) : null,
  ]);
}

function pathPanel(title, nodes, tone) {
  return panel(title, nodes?.length
    ? h("div", { className: `topology-path path-${tone}` }, nodes.map((node, index) => pathNode(node, index, nodes.length)))
    : emptyState("链路信息未接入", "系统保留未知节点，不会推测或补造实际连接。"), { kicker: tone === "power" ? "强电路径" : "网络路径" });
}

/* ---------- 设备详情卡片（服务器查询结果） ---------- */

function deviceStatusLabel(status) {
  const labels = { running: "运行中", pending: "待上架", migrated: "已迁移", cancelled: "已取消" };
  return labels[status] ?? status ?? "未知";
}

function deviceStatusTone(status) {
  const tones = { running: "ok", pending: "warning" };
  return tones[status] ?? "neutral";
}

function deviceDetailView(result) {
  const data = result.device;
  const device = data.device;
  const rack = data.rack;
  const pdu = data.power?.find?.((node) => node.type === "pdu");
  const access = data.network?.find?.((node) => node.type === "access_switch");
  const endU = device.start_u + device.u_size - 1;

  return h("div", { className: "topology-results" }, [
    h("section", { className: "topology-subject" }, [
      h("div", {}, [
        h("p", { className: "section-kicker", text: device.id }),
        h("h2", { text: device.hostname || device.id }),
        h("p", { text: `${rack?.id ?? "未知机柜"} · ${rack?.name ?? ""} / ${device.layer_id} / U${device.start_u}–U${endU}` }),
      ]),
      h("div", { className: "intro-badges" }, [
        sourceBadge(device.data_source),
        statusBadge(deviceStatusLabel(device.status), deviceStatusTone(device.status)),
        statusBadge("冗余未核实", "warning"),
      ]),
    ]),

    // 设备详细信息卡片
    panel("服务器详细信息", h("div", { className: "device-detail-card" }, [
      h("div", {}, [
        h("dl", {}, [
          h("dt", { text: "ITcode" }), h("dd", { text: device.it_code ?? "未接入" }),
          h("dt", { text: "资产编号" }), h("dd", { text: device.asset_id ?? "未接入" }),
          h("dt", { text: "设备型号" }), h("dd", { text: device.model ?? "未接入" }),
          h("dt", { text: "序列号" }), h("dd", { text: device.serial ?? "未接入" }),
          h("dt", { text: "机柜位置" }), h("dd", { text: `${rack?.id ?? "-"} / ${device.layer_id}` }),
          h("dt", { text: "U 位" }), h("dd", { text: `U${device.start_u}–U${endU}（${device.u_size}U）` }),
          h("dt", { text: "设备高度" }), h("dd", { text: `${device.u_size}U` }),
        ]),
      ]),
      h("div", {}, [
        h("dl", {}, [
          h("dt", { text: "额定功率" }), h("dd", { text: formatPower(device.rated_power_w) }),
          h("dt", { text: "实时功率" }), h("dd", { text: device.real_power_w === null ? "未接入" : formatPower(device.real_power_w) }),
          h("dt", { text: "重量" }), h("dd", { text: `${device.weight_kg} kg` }),
          h("dt", { text: "网络端口" }), h("dd", { text: device.network_ports }),
          h("dt", { text: "IP / VLAN" }), h("dd", { text: `${device.ip ?? "-"} / ${device.vlan ?? "-"}` }),
          h("dt", { text: "业务 / 责任人" }), h("dd", { text: `${device.business ?? "-"} / ${device.owner ?? "-"}` }),
        ]),
      ]),
    ]), { kicker: "设备详情" }),

    h("section", { className: "topology-columns" }, [pathPanel("强电路径", data.power, "power"), pathPanel("网络路径", data.network, "network")]),
    h("p", { className: "redundancy-callout", text: "图纸存在多条配电分支，但当前数据不足以证明设备级 A/B 冗余，本系统不作冗余承诺。" }),
  ]);
}

/* ---------- 设备卡片（机柜列表 / 搜索结果） ---------- */

function deviceInfoCard(device, onClick) {
  const statusClass = `status-${device.status ?? "unknown"}`;
  return h("button", {
    type: "button",
    className: `device-info-card ${statusClass}`,
    onClick: () => onClick(device),
    "aria-label": `查看服务器 ${device.hostname || device.id}`,
  }, [
    h("div", { className: "device-card-head" }, [
      h("div", {}, [
        h("strong", { text: device.id }),
        h("span", { className: "device-hostname", text: device.hostname || device.model || "" }),
      ]),
      h("span", { className: "device-card-pos", text: `${device.layer_id} · ${device.u_position}` }),
    ]),
    h("dl", { className: "device-card-specs" }, [
      h("div", {}, [h("dt", { text: "型号" }), h("dd", { text: device.model || "-" })]),
      h("div", {}, [h("dt", { text: "功率" }), h("dd", { text: formatPower(device.rated_power_w) })]),
      h("div", {}, [h("dt", { text: "重量" }), h("dd", { text: `${device.weight_kg} kg` })]),
      h("div", {}, [h("dt", { text: "端口" }), h("dd", { text: `${device.network_ports}` })]),
      h("div", {}, [h("dt", { text: "IP" }), h("dd", { text: device.ip || "-" })]),
      h("div", {}, [h("dt", { text: "状态" }), h("dd", { text: deviceStatusLabel(device.status) })]),
    ]),
    h("div", { className: "device-card-links" }, [
      device.pdu
        ? h("span", { className: "pdu-link", text: `PDU: ${device.pdu.label}` })
        : h("span", { text: "PDU: 未接入" }),
      device.switch_port
        ? h("span", { className: "net-link", text: `SW: ${device.switch_port.switch_id} / ${device.switch_port.switch_port}` })
        : h("span", { text: "交换机: 未接入" }),
      device.business ? h("span", { text: `业务: ${device.business}` }) : null,
    ]),
  ]);
}

/* ---------- 机柜设备列表（机柜查询结果） ---------- */

function rackDevicesView(result) {
  const rack = result.rack;
  const devices = result.devices;
  const isNetwork = rack.role === "network";
  const roleLabel = isNetwork ? "网络机柜" : "服务器机柜";
  const dividerStr = rack.dividers_u ? rack.dividers_u.join(" / ") + "U" : "-";

  return h("div", { className: "topology-results" }, [
    h("section", { className: `rack-info-banner ${isNetwork ? "network-rack" : ""}` }, [
      h("div", {}, [
        h("p", { className: "section-kicker", text: `${rack.source_id} / ${roleLabel}` }),
        h("h3", { text: `${rack.id} · ${rack.name}` }),
        h("p", { text: `${rack.height_u}U · 分层线 ${dividerStr} · 每层仅预留一次 2U` }),
        h("p", { text: `配电来源: ${rack.source_name ?? rack.source_id} · 接入交换机: ${rack.network_switch_name ?? rack.network_switch_id ?? "未接入"}` }),
        h("div", { className: "rack-stats" }, [
          h("span", { text: `设计容量 ${formatPower(rack.design_power_w)}` }),
          h("span", { text: `承重上限 ${rack.max_weight_kg} kg` }),
          h("span", { text: `端口上限 ${rack.network_port_limit}` }),
          h("span", { text: `共 ${devices.length} 台设备` }),
        ]),
      ]),
      h("div", { className: "intro-badges" }, [
        sourceBadge(rack.data_source),
        statusBadge(roleLabel, "neutral"),
      ]),
    ]),

    devices.length === 0
      ? emptyState("该机柜无设备", "该机柜当前没有上架的服务器或网络设备。")
      : panel(`机柜内设备列表（${devices.length} 台）`, h("div", { className: "device-card-grid" },
        devices.map((device) => deviceInfoCard(device, (d) => queryTopology(d.id)))
      ), { kicker: "设备清单" }),
  ]);
}

/* ---------- 设备搜索结果（模糊匹配多设备） ---------- */

function deviceSearchView(result) {
  const matches = result.matches || [];
  if (matches.length === 0) {
    return h("div", { className: "topology-results" }, [
      h("section", { className: "device-search-header" }, [
        h("div", {}, [
          h("strong", { text: `未找到匹配: "${result.query}"` }),
          h("span", { text: "请尝试输入完整设备 ID（如 SRV-DEMO-10U）、机柜编号（如 CAB-09）或 IP 地址" }),
        ]),
      ]),
    ]);
  }
  return h("div", { className: "topology-results" }, [
    h("section", { className: "device-search-header" }, [
      h("div", {}, [
        h("strong", { text: `搜索: "${result.query}"` }),
        h("span", { text: `找到 ${matches.length} 台匹配设备` }),
      ]),
      result.exact ? statusBadge("精确匹配", "ok") : statusBadge("模糊匹配", "warning"),
    ]),
    panel(`匹配设备（${matches.length}）`, h("div", { className: "device-card-grid" },
      matches.map((device) => deviceInfoCard(device, (d) => queryTopology(d.id)))
    ), { kicker: "搜索结果" }),
  ]);
}

/* ---------- 聚合视图（电源/交换机查询） ---------- */

function matchAggregate(result) {
  const query = result.query.toUpperCase();
  const power = result.power;
  const network = result.network;
  let racks = power.cabinets;
  let sources = power.power_sources;
  let switches = network.access_switches;

  if (query.startsWith("CAB-")) {
    racks = power.cabinets.filter((rack) => rack.id === query);
    sources = power.power_sources.filter((source) => racks.some((rack) => rack.source_id === source.id));
    switches = network.access_switches.filter((item) => item.connected_rack_ids.includes(query));
  } else if (query.startsWith("JG") || query === "KT1") {
    sources = power.power_sources.filter((source) => source.id === query);
    racks = power.cabinets.filter((rack) => rack.source_id === query);
    const rackIds = new Set(racks.map((rack) => rack.id));
    switches = network.access_switches.filter((item) => item.connected_rack_ids.some((rackId) => rackIds.has(rackId)));
  } else if (query.startsWith("ASW-")) {
    switches = network.access_switches.filter((item) => item.id === query);
    const rackIds = new Set(switches.flatMap((item) => item.connected_rack_ids));
    racks = power.cabinets.filter((rack) => rackIds.has(rack.id));
    sources = power.power_sources.filter((source) => racks.some((rack) => rack.source_id === source.id));
  } else if (query && query !== network.core.id) {
    racks = [];
    sources = [];
    switches = [];
  }
  return { racks, sources, switches };
}

function aggregateTopology(result) {
  const { racks, sources, switches } = matchAggregate(result);
  const network = result.network;
  const selection = h("section", { className: "topology-selection" }, [
    h("div", {}, [
      h("p", { className: "section-kicker", text: "已选追踪" }),
      h("strong", { text: result.query || "全部设计对象" }),
      h("span", { text: `命中 ${sources.length} 个电源、${racks.length} 个机柜、${switches.length} 台接入交换机` }),
    ]),
    statusBadge(sources.length + racks.length + switches.length ? "关联对象已联动" : "未找到对象", sources.length + racks.length + switches.length ? "ok" : "warning"),
  ]);
  const powerBody = h("div", { className: "aggregate-map" }, [
    ...sources.map((source) => queryButton(source.id, `查看 ${source.id} 链路`, [sourceBadge(source.data_source), h("strong", { text: source.id }), h("span", { text: source.name }), h("code", { text: source.calculated_load_w === null ? "计算负载：未接入" : `图纸计算负载 ${(source.calculated_load_w / 1000).toFixed(0)} kW` })], "aggregate-node power-source-node")),
    ...racks.map((rack) => queryButton(rack.id, `查看 ${rack.id} 机柜设备`, [h("strong", { text: rack.id }), h("span", { text: `${rack.source_id} · ${(rack.design_power_w / 1000).toFixed(0)} kW` })])),
  ]);
  const networkBody = h("div", { className: "aggregate-map" }, [
    queryButton(network.core.id, `查看 ${network.core.id} 链路`, [sourceBadge(network.core.data_source), h("strong", { text: network.core.id }), h("span", { text: network.core.name })], "aggregate-node core-node"),
    ...switches.map((item) => queryButton(item.id, `查看 ${item.id} 链路`, [sourceBadge(item.data_source), h("strong", { text: item.id }), h("span", { text: `${item.uplink} → ${item.connected_rack_ids.join(" / ")}` })], "aggregate-node network-node")),
  ]);
  return h("div", { className: "topology-results" }, [
    selection,
    h("section", { className: "topology-columns" }, [panel("强电对象", powerBody, { kicker: "配电对象" }), panel("弱电对象", networkBody, { kicker: "网络对象" })]),
  ]);
}

/* ---------- 主渲染入口 ---------- */

export function renderTopology(container, state) {
  const form = h("form", { className: "topology-search" }, [
    h("label", { className: "form-field" }, ["机柜名称或服务器名称/IP", h("input", { name: "query", value: state.topologyResult?.query || state.route.id || "CAB-01", placeholder: "CAB-01 / SRV-DEMO-10U / gpu-demo-01 / 10.0.9.11" })]),
    h("button", { type: "submit", className: "primary-button", text: "查询" }),
  ]);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = new FormData(form).get("query");
    try { await loadTopology(query); }
    catch (error) { showToast(`${error.code ?? "TOPOLOGY_FAILED"} · ${error.message}`, "danger"); }
  });

  const quickQueries = h("div", { className: "topology-quick-query" }, [
    h("span", { text: "快速查询" }),
    ...["CAB-01", "CAB-09", "SRV-DEMO-10U", "gpu-demo-01", "JG1", "ASW-05"].map((id) => queryButton(id, `查询 ${id}`, id, "query-chip")),
  ]);

  const collectorOffline = state.alarms.some((alarm) => alarm.status !== "resolved" && alarm.scenario === "collector_offline");
  const intro = h("section", { className: "view-intro" }, [
    h("div", {}, [
      h("p", { className: "section-kicker", text: "机柜与服务器查询" }),
      h("h2", { text: "强弱电链路与设备详情" }),
      h("p", { text: "输入机柜名称查看机柜内所有服务器的详细信息卡片；输入服务器名称、ID、IP 或资产编号查看该服务器的位置与详细信息。" }),
    ]),
    statusBadge(collectorOffline ? "采集离线 · 使用设计数据" : "设计链路可查", collectorOffline ? "warning" : "ok"),
  ]);
  const searchPanel = panel("查询对象", [form, quickQueries], { kicker: "追踪" });

  let result;
  if (!state.topologyResult) {
    result = emptyState("输入机柜或服务器名称开始查询", "支持机柜编号（如 CAB-09）、服务器 ID（如 SRV-DEMO-10U）、主机名（如 gpu-demo-01）、IP 地址等多种查询方式。");
  } else {
    const kind = state.topologyResult.kind;
    if (kind === "device") result = deviceDetailView(state.topologyResult);
    else if (kind === "rack_devices") result = rackDevicesView(state.topologyResult);
    else if (kind === "device_search") result = deviceSearchView(state.topologyResult);
    else result = aggregateTopology(state.topologyResult);
  }

  container.replaceChildren(intro, searchPanel, result);
}
