import { emptyState, h, openDialog, panel, showToast, statusBadge } from "../components.js";
import { resetDemoState } from "../state.js";

const actionNames = {
  plan_created: "方案创建",
  plan_candidate_selected: "候选方案选择",
  plan_succeeded: "方案执行成功",
  plan_failed: "方案执行失败并回滚",
  demo_alarm_triggered: "演示报警触发",
  alarm_acknowledged: "报警已确认",
  alarm_diagnosing: "开始诊断",
  alarm_diagnosed: "诊断完成",
  alarm_remediation_planned: "处置方案生成",
  alarm_resolved: "恢复验证通过",
  demo_state_reset: "演示数据重置",
};

const entityTypeNames = {
  plan: "方案",
  alarm: "报警",
};

const fieldLabels = {
  kind: "方案类型",
  status: "状态",
  risk: "风险等级",
  strategy_id: "部署策略",
  device_ids: "设备编号",
  device_it_codes: "ITcode",
  candidate_id: "候选方案ID",
  rack_id: "目标机柜",
  layer_id: "目标层级",
  score: "方案评分",
  stages: "执行阶段",
  rolled_back: "是否回滚",
  solver_engine: "求解器引擎",
  solver_status: "求解器状态",
  solver_duration_ms: "求解耗时(ms)",
  solver_candidate_count: "候选数量",
  solver_fallback_reason: "回退原因",
  solver_validation_rejected_count: "规则拒绝数",
  baseline_candidate_id: "基线候选",
  final_candidate_id: "最终候选",
  agent_model: "Agent模型",
  agent_status: "Agent状态",
};

const kindNames = {
  placement: "设备上架",
  removal: "设备取出",
  alarm_remediation: "报警处置",
  change: "变更",
};

const strategyNames = {
  balanced_optimal: "综合最优",
  consolidated: "集中部署",
  load_balanced: "负载均衡",
};

const riskNames = {
  safe: "安全",
  warning: "警告",
  blocked: "阻断",
};

const solverStatusNames = {
  optimal: "最优解",
  feasible: "可行解",
  not_run: "未运行",
  unknown: "未知",
};

const agentStatusNames = {
  healthy: "正常",
  degraded: "降级",
  not_used: "未使用",
  not_configured: "未配置",
  available: "可用",
};

const stageNames = {
  locked: "资源锁定",
  written: "数据写入",
  verified: "验证通过",
  audited: "审计记录",
};

function translateValue(key, value) {
  if (value === null || value === undefined) return "无";
  if (key === "kind" && kindNames[value]) return kindNames[value];
  if (key === "strategy_id" && strategyNames[value]) return strategyNames[value];
  if (key === "risk" && riskNames[value]) return riskNames[value];
  if (key === "solver_status" && solverStatusNames[value]) return solverStatusNames[value];
  if (key === "agent_status" && agentStatusNames[value]) return agentStatusNames[value];
  if (key === "rolled_back") return value ? "是" : "否";
  if (key === "stages" && Array.isArray(value)) {
    return value.map((stage) => stageNames[stage] ?? stage).join(" → ");
  }
  if (Array.isArray(value)) {
    return value.length > 0 ? value.join("、") : "无";
  }
  if (typeof value === "boolean") return value ? "是" : "否";
  return String(value);
}

function formatEvidenceDetails(details) {
  if (!details || Object.keys(details).length === 0) {
    return h("p", { className: "evidence-empty", text: "无详细证据" });
  }

  const importantKeys = ["kind", "device_ids", "device_it_codes", "status", "risk", "strategy_id", "stages", "rolled_back", "rack_id", "layer_id"];
  const secondaryKeys = ["candidate_id", "score", "solver_engine", "solver_status", "solver_duration_ms", "solver_candidate_count", "agent_status", "agent_model", "baseline_candidate_id", "final_candidate_id"];
  const otherKeys = Object.keys(details).filter((key) => !importantKeys.includes(key) && !secondaryKeys.includes(key));

  const renderGroup = (keys, title, highlight = false) => {
    const items = keys.filter((key) => details[key] !== undefined && (!(Array.isArray(details[key])) || details[key].length > 0));
    if (items.length === 0) return null;
    return h("div", { className: `evidence-group ${highlight ? "evidence-highlight" : ""}` }, [
      title ? h("h5", { text: title }) : null,
      h("dl", {}, items.flatMap((key) => [
        h("dt", { text: fieldLabels[key] ?? key }),
        h("dd", { text: translateValue(key, details[key]) }),
      ])),
    ]);
  };

  return h("div", { className: "evidence-content" }, [
    renderGroup(importantKeys, "核心信息", true),
    renderGroup(secondaryKeys, "求解与执行详情"),
    otherKeys.length > 0 ? renderGroup(otherKeys, "其他信息") : null,
  ]);
}

function auditTimeline(items) {
  if (!items.length) return emptyState("暂无审计记录", "创建方案、触发报警或执行变更后，记录将按时间显示在这里。");
  return h("ol", { className: "audit-timeline" }, items.map((entry) => {
    const deviceIds = entry.details?.device_ids ?? [];
    const deviceItCodes = entry.details?.device_it_codes ?? [];
    const entityTypeLabel = entityTypeNames[entry.entity_type] ?? entry.entity_type;
    const deviceSummary = deviceIds.length > 0
      ? h("p", { className: "audit-device-summary" }, [
        h("span", { text: "设备：" }),
        h("strong", { text: deviceIds.join("、") }),
        deviceItCodes.length > 0 ? h("span", { text: ` (ITcode: ${deviceItCodes.join("、")})` }) : null,
      ])
      : null;

    return h("li", {}, [
      h("span", { className: "timeline-mark", "aria-hidden": "true" }),
      h("details", { className: "audit-entry" }, [
        h("summary", {}, [
          h("div", { className: "audit-entry-head" }, [
            h("strong", { text: actionNames[entry.action] ?? entry.action }),
            statusBadge(entityTypeLabel, entry.action.includes("failed") ? "danger" : entry.action.includes("resolved") || entry.action.includes("succeeded") ? "ok" : "neutral"),
          ]),
          h("p", { text: `${entry.entity_id} · 操作人 ${entry.actor}` }),
          deviceSummary,
          h("time", { datetime: entry.at, text: new Date(entry.at).toLocaleString("zh-CN") }),
        ]),
        h("div", { className: "audit-entry-details" }, [
          h("dl", {}, [
            h("div", {}, [h("dt", { text: "记录编号" }), h("dd", { text: entry.id })]),
            h("div", {}, [h("dt", { text: "对象类型" }), h("dd", { text: entityTypeLabel })]),
            h("div", {}, [h("dt", { text: "对象编号" }), h("dd", { text: entry.entity_id })]),
            h("div", {}, [h("dt", { text: "动作类型" }), h("dd", { text: actionNames[entry.action] ?? entry.action })]),
            h("div", {}, [h("dt", { text: "操作人" }), h("dd", { text: entry.actor })]),
            h("div", {}, [h("dt", { text: "时间" }), h("dd", { text: new Date(entry.at).toLocaleString("zh-CN") })]),
          ]),
          h("div", { className: "audit-evidence" }, [
            h("span", { text: "详细证据" }),
            formatEvidenceDetails(entry.details),
          ]),
        ]),
      ]),
    ]);
  }));
}

function openResetDialog() {
  const content = h("div", { className: "confirmation-content" }, [
    h("p", { className: "section-kicker", text: "管理确认" }),
    h("h2", { text: "重置全部演示数据？" }),
    h("p", { className: "confirmation-lead", text: "这会恢复 L5-A2-08 的 22 柜标准种子，清除当前方案、报警和变更记录，再写入一条新的重置审计。" }),
    h("div", { className: "confirmation-actions" }, [
      h("button", { type: "button", className: "secondary-button", text: "取消", onClick: () => close() }),
      h("button", { type: "button", className: "primary-button", text: "确认重置演示数据", onClick: async (event) => {
        event.currentTarget.disabled = true;
        try { await resetDemoState(); close(); showToast("演示数据已恢复为标准种子"); }
        catch (error) { event.currentTarget.disabled = false; showToast(`${error.code ?? "RESET_FAILED"} · ${error.message}`, "danger"); }
      } }),
    ]),
  ]);
  const close = openDialog(content, { label: "重置演示数据" });
}

export function renderAudit(container, state) {
  const filterId = state.route.id;
  const items = filterId ? state.audit.filter((entry) => entry.entity_id === filterId || JSON.stringify(entry.details).includes(filterId)) : state.audit;
  const intro = h("section", { className: "view-intro" }, [
    h("div", {}, [h("p", { className: "section-kicker", text: "谁 / 何时 / 什么 / 结果" }), h("h2", { text: "变更与诊断审计" }), h("p", { text: filterId ? `正在查看与 ${filterId} 相关的记录。` : "每一次方案创建、最终确认、执行、回滚和恢复验证都有可追溯记录。" })]),
    state.session.role === "admin" ? h("button", { type: "button", className: "secondary-button", text: "重置演示数据", onClick: openResetDialog }) : statusBadge("只读查看", "neutral"),
  ]);
  container.replaceChildren(intro, panel("审计时间线", auditTimeline(items), { kicker: "不可变追溯" }));
}
